import { _ as __exportAll, a as buildSignedEgoTx, c as generateSeed, d as publicKeyToAddress, f as seedToKeypair, h as require_dist, i as validateAddress, l as hexToSeed, m as signMessage, n as fetchAssetBalance, o as decryptSeed, p as seedToMnemonic, r as fetchTokenMeta, s as encryptSeed, t as CHAINS, u as mnemonicToSeed } from "./chunks/assets-D7pLHZXZ.js";
//#region src/shared/rpc.ts
var DEFAULT_RPC_URL = "http://127.0.0.1:47395";
async function fetchJSON(url, options) {
	const res = await fetch(url, {
		...options,
		headers: {
			"Content-Type": "application/json",
			...options?.headers ?? {}
		}
	});
	if (!res.ok) {
		const err = await res.json().catch(() => ({ error: res.statusText }));
		throw new Error(err.error ?? `HTTP ${res.status}`);
	}
	return res.json();
}
async function jsonRpc(rpcUrl, method, params) {
	const res = await fetchJSON(rpcUrl, {
		method: "POST",
		body: JSON.stringify({
			jsonrpc: "2.0",
			id: 1,
			method,
			params
		})
	});
	if (res.error) throw new Error(res.error.message ?? `${method} failed`);
	return res.result;
}
async function getBalance(address, rpcUrl = DEFAULT_RPC_URL) {
	const r = await jsonRpc(rpcUrl, "wallet.getBalance", { address });
	return {
		address,
		balance_uegoc: r?.uegoc ?? 0,
		balance_egoc: r?.egoc ?? 0
	};
}
async function submitTx(tx, rpcUrl = DEFAULT_RPC_URL) {
	return jsonRpc(rpcUrl, "tx.submit", { tx });
}
async function getNonceInfo(address, rpcUrl = DEFAULT_RPC_URL) {
	return jsonRpc(rpcUrl, "wallet.getNonce", { address });
}
async function getBlocks(rpcUrl = DEFAULT_RPC_URL) {
	return fetchJSON(`${rpcUrl}/chain/blocks`);
}
async function getTransactions(rpcUrl = DEFAULT_RPC_URL) {
	return fetchJSON(`${rpcUrl}/chain/transactions`);
}
async function getHealth(rpcUrl = DEFAULT_RPC_URL) {
	return fetchJSON(`${rpcUrl}/health`);
}
async function requestFaucet(address, rpcUrl = DEFAULT_RPC_URL) {
	return fetchJSON(`${rpcUrl}/faucet?to=${encodeURIComponent(address)}`);
}
//#endregion
//#region src/shared/types.ts
var NETWORKS = {
	testnet: {
		name: "Ego Testnet",
		chainId: "0x1",
		rpcUrl: "http://127.0.0.1:47395"
	},
	mainnet: {
		name: "Ego Mainnet",
		chainId: "0x1",
		rpcUrl: "http://127.0.0.1:47395"
	}
};
//#endregion
//#region node_modules/@noble/hashes/esm/_assert.js
function number(n) {
	if (!Number.isSafeInteger(n) || n < 0) throw new Error(`positive integer expected, not ${n}`);
}
function isBytes$1(a) {
	return a instanceof Uint8Array || a != null && typeof a === "object" && a.constructor.name === "Uint8Array";
}
function bytes(b, ...lengths) {
	if (!isBytes$1(b)) throw new Error("Uint8Array expected");
	if (lengths.length > 0 && !lengths.includes(b.length)) throw new Error(`Uint8Array expected of length ${lengths}, not of length=${b.length}`);
}
function hash(h) {
	if (typeof h !== "function" || typeof h.create !== "function") throw new Error("Hash should be wrapped by utils.wrapConstructor");
	number(h.outputLen);
	number(h.blockLen);
}
function exists(instance, checkFinished = true) {
	if (instance.destroyed) throw new Error("Hash instance has been destroyed");
	if (checkFinished && instance.finished) throw new Error("Hash#digest() has already been called");
}
function output(out, instance) {
	bytes(out);
	const min = instance.outputLen;
	if (out.length < min) throw new Error(`digestInto() expects output buffer of length at least ${min}`);
}
//#endregion
//#region node_modules/@noble/hashes/esm/crypto.js
var crypto$1 = typeof globalThis === "object" && "crypto" in globalThis ? globalThis.crypto : void 0;
//#endregion
//#region node_modules/@noble/hashes/esm/utils.js
/*! noble-hashes - MIT License (c) 2022 Paul Miller (paulmillr.com) */
var u32 = (arr) => new Uint32Array(arr.buffer, arr.byteOffset, Math.floor(arr.byteLength / 4));
var createView = (arr) => new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
var rotr = (word, shift) => word << 32 - shift | word >>> shift;
var rotl = (word, shift) => word << shift | word >>> 32 - shift >>> 0;
var isLE = new Uint8Array(new Uint32Array([287454020]).buffer)[0] === 68;
var byteSwap = (word) => word << 24 & 4278190080 | word << 8 & 16711680 | word >>> 8 & 65280 | word >>> 24 & 255;
function byteSwap32(arr) {
	for (let i = 0; i < arr.length; i++) arr[i] = byteSwap(arr[i]);
}
/**
* @example utf8ToBytes('abc') // new Uint8Array([97, 98, 99])
*/
function utf8ToBytes$1(str) {
	if (typeof str !== "string") throw new Error(`utf8ToBytes expected string, got ${typeof str}`);
	return new Uint8Array(new TextEncoder().encode(str));
}
/**
* Normalizes (non-hex) string or Uint8Array to Uint8Array.
* Warning: when Uint8Array is passed, it would NOT get copied.
* Keep in mind for future mutable operations.
*/
function toBytes(data) {
	if (typeof data === "string") data = utf8ToBytes$1(data);
	bytes(data);
	return data;
}
/**
* Copies several Uint8Arrays into one.
*/
function concatBytes$1(...arrays) {
	let sum = 0;
	for (let i = 0; i < arrays.length; i++) {
		const a = arrays[i];
		bytes(a);
		sum += a.length;
	}
	const res = new Uint8Array(sum);
	for (let i = 0, pad = 0; i < arrays.length; i++) {
		const a = arrays[i];
		res.set(a, pad);
		pad += a.length;
	}
	return res;
}
var Hash = class {
	clone() {
		return this._cloneInto();
	}
};
({}).toString;
function wrapConstructor(hashCons) {
	const hashC = (msg) => hashCons().update(toBytes(msg)).digest();
	const tmp = hashCons();
	hashC.outputLen = tmp.outputLen;
	hashC.blockLen = tmp.blockLen;
	hashC.create = () => hashCons();
	return hashC;
}
/**
* Secure PRNG. Uses `crypto.getRandomValues`, which defers to OS.
*/
function randomBytes(bytesLength = 32) {
	if (crypto$1 && typeof crypto$1.getRandomValues === "function") return crypto$1.getRandomValues(new Uint8Array(bytesLength));
	if (crypto$1 && typeof crypto$1.randomBytes === "function") return crypto$1.randomBytes(bytesLength);
	throw new Error("crypto.getRandomValues must be defined");
}
//#endregion
//#region node_modules/@noble/hashes/esm/_md.js
/**
* Polyfill for Safari 14
*/
function setBigUint64(view, byteOffset, value, isLE) {
	if (typeof view.setBigUint64 === "function") return view.setBigUint64(byteOffset, value, isLE);
	const _32n = BigInt(32);
	const _u32_max = BigInt(4294967295);
	const wh = Number(value >> _32n & _u32_max);
	const wl = Number(value & _u32_max);
	const h = isLE ? 4 : 0;
	const l = isLE ? 0 : 4;
	view.setUint32(byteOffset + h, wh, isLE);
	view.setUint32(byteOffset + l, wl, isLE);
}
/**
* Choice: a ? b : c
*/
var Chi = (a, b, c) => a & b ^ ~a & c;
/**
* Majority function, true if any two inputs is true
*/
var Maj = (a, b, c) => a & b ^ a & c ^ b & c;
/**
* Merkle-Damgard hash construction base class.
* Could be used to create MD5, RIPEMD, SHA1, SHA2.
*/
var HashMD = class extends Hash {
	constructor(blockLen, outputLen, padOffset, isLE) {
		super();
		this.blockLen = blockLen;
		this.outputLen = outputLen;
		this.padOffset = padOffset;
		this.isLE = isLE;
		this.finished = false;
		this.length = 0;
		this.pos = 0;
		this.destroyed = false;
		this.buffer = new Uint8Array(blockLen);
		this.view = createView(this.buffer);
	}
	update(data) {
		exists(this);
		const { view, buffer, blockLen } = this;
		data = toBytes(data);
		const len = data.length;
		for (let pos = 0; pos < len;) {
			const take = Math.min(blockLen - this.pos, len - pos);
			if (take === blockLen) {
				const dataView = createView(data);
				for (; blockLen <= len - pos; pos += blockLen) this.process(dataView, pos);
				continue;
			}
			buffer.set(data.subarray(pos, pos + take), this.pos);
			this.pos += take;
			pos += take;
			if (this.pos === blockLen) {
				this.process(view, 0);
				this.pos = 0;
			}
		}
		this.length += data.length;
		this.roundClean();
		return this;
	}
	digestInto(out) {
		exists(this);
		output(out, this);
		this.finished = true;
		const { buffer, view, blockLen, isLE } = this;
		let { pos } = this;
		buffer[pos++] = 128;
		this.buffer.subarray(pos).fill(0);
		if (this.padOffset > blockLen - pos) {
			this.process(view, 0);
			pos = 0;
		}
		for (let i = pos; i < blockLen; i++) buffer[i] = 0;
		setBigUint64(view, blockLen - 8, BigInt(this.length * 8), isLE);
		this.process(view, 0);
		const oview = createView(out);
		const len = this.outputLen;
		if (len % 4) throw new Error("_sha2: outputLen should be aligned to 32bit");
		const outLen = len / 4;
		const state = this.get();
		if (outLen > state.length) throw new Error("_sha2: outputLen bigger than state");
		for (let i = 0; i < outLen; i++) oview.setUint32(4 * i, state[i], isLE);
	}
	digest() {
		const { buffer, outputLen } = this;
		this.digestInto(buffer);
		const res = buffer.slice(0, outputLen);
		this.destroy();
		return res;
	}
	_cloneInto(to) {
		to || (to = new this.constructor());
		to.set(...this.get());
		const { blockLen, buffer, length, finished, destroyed, pos } = this;
		to.length = length;
		to.pos = pos;
		to.finished = finished;
		to.destroyed = destroyed;
		if (length % blockLen) to.buffer.set(buffer);
		return to;
	}
};
//#endregion
//#region node_modules/@noble/hashes/esm/sha256.js
var SHA256_K = /* @__PURE__ */ new Uint32Array([
	1116352408,
	1899447441,
	3049323471,
	3921009573,
	961987163,
	1508970993,
	2453635748,
	2870763221,
	3624381080,
	310598401,
	607225278,
	1426881987,
	1925078388,
	2162078206,
	2614888103,
	3248222580,
	3835390401,
	4022224774,
	264347078,
	604807628,
	770255983,
	1249150122,
	1555081692,
	1996064986,
	2554220882,
	2821834349,
	2952996808,
	3210313671,
	3336571891,
	3584528711,
	113926993,
	338241895,
	666307205,
	773529912,
	1294757372,
	1396182291,
	1695183700,
	1986661051,
	2177026350,
	2456956037,
	2730485921,
	2820302411,
	3259730800,
	3345764771,
	3516065817,
	3600352804,
	4094571909,
	275423344,
	430227734,
	506948616,
	659060556,
	883997877,
	958139571,
	1322822218,
	1537002063,
	1747873779,
	1955562222,
	2024104815,
	2227730452,
	2361852424,
	2428436474,
	2756734187,
	3204031479,
	3329325298
]);
var SHA256_IV = /* @__PURE__ */ new Uint32Array([
	1779033703,
	3144134277,
	1013904242,
	2773480762,
	1359893119,
	2600822924,
	528734635,
	1541459225
]);
var SHA256_W = /* @__PURE__ */ new Uint32Array(64);
var SHA256 = class extends HashMD {
	constructor() {
		super(64, 32, 8, false);
		this.A = SHA256_IV[0] | 0;
		this.B = SHA256_IV[1] | 0;
		this.C = SHA256_IV[2] | 0;
		this.D = SHA256_IV[3] | 0;
		this.E = SHA256_IV[4] | 0;
		this.F = SHA256_IV[5] | 0;
		this.G = SHA256_IV[6] | 0;
		this.H = SHA256_IV[7] | 0;
	}
	get() {
		const { A, B, C, D, E, F, G, H } = this;
		return [
			A,
			B,
			C,
			D,
			E,
			F,
			G,
			H
		];
	}
	set(A, B, C, D, E, F, G, H) {
		this.A = A | 0;
		this.B = B | 0;
		this.C = C | 0;
		this.D = D | 0;
		this.E = E | 0;
		this.F = F | 0;
		this.G = G | 0;
		this.H = H | 0;
	}
	process(view, offset) {
		for (let i = 0; i < 16; i++, offset += 4) SHA256_W[i] = view.getUint32(offset, false);
		for (let i = 16; i < 64; i++) {
			const W15 = SHA256_W[i - 15];
			const W2 = SHA256_W[i - 2];
			const s0 = rotr(W15, 7) ^ rotr(W15, 18) ^ W15 >>> 3;
			SHA256_W[i] = (rotr(W2, 17) ^ rotr(W2, 19) ^ W2 >>> 10) + SHA256_W[i - 7] + s0 + SHA256_W[i - 16] | 0;
		}
		let { A, B, C, D, E, F, G, H } = this;
		for (let i = 0; i < 64; i++) {
			const sigma1 = rotr(E, 6) ^ rotr(E, 11) ^ rotr(E, 25);
			const T1 = H + sigma1 + Chi(E, F, G) + SHA256_K[i] + SHA256_W[i] | 0;
			const T2 = (rotr(A, 2) ^ rotr(A, 13) ^ rotr(A, 22)) + Maj(A, B, C) | 0;
			H = G;
			G = F;
			F = E;
			E = D + T1 | 0;
			D = C;
			C = B;
			B = A;
			A = T1 + T2 | 0;
		}
		A = A + this.A | 0;
		B = B + this.B | 0;
		C = C + this.C | 0;
		D = D + this.D | 0;
		E = E + this.E | 0;
		F = F + this.F | 0;
		G = G + this.G | 0;
		H = H + this.H | 0;
		this.set(A, B, C, D, E, F, G, H);
	}
	roundClean() {
		SHA256_W.fill(0);
	}
	destroy() {
		this.set(0, 0, 0, 0, 0, 0, 0, 0);
		this.buffer.fill(0);
	}
};
/**
* SHA2-256 hash function
* @param message - data that would be hashed
*/
var sha256 = /* @__PURE__ */ wrapConstructor(() => new SHA256());
//#endregion
//#region node_modules/@noble/hashes/esm/hmac.js
var HMAC = class extends Hash {
	constructor(hash$1, _key) {
		super();
		this.finished = false;
		this.destroyed = false;
		hash(hash$1);
		const key = toBytes(_key);
		this.iHash = hash$1.create();
		if (typeof this.iHash.update !== "function") throw new Error("Expected instance of class which extends utils.Hash");
		this.blockLen = this.iHash.blockLen;
		this.outputLen = this.iHash.outputLen;
		const blockLen = this.blockLen;
		const pad = new Uint8Array(blockLen);
		pad.set(key.length > blockLen ? hash$1.create().update(key).digest() : key);
		for (let i = 0; i < pad.length; i++) pad[i] ^= 54;
		this.iHash.update(pad);
		this.oHash = hash$1.create();
		for (let i = 0; i < pad.length; i++) pad[i] ^= 106;
		this.oHash.update(pad);
		pad.fill(0);
	}
	update(buf) {
		exists(this);
		this.iHash.update(buf);
		return this;
	}
	digestInto(out) {
		exists(this);
		bytes(out, this.outputLen);
		this.finished = true;
		this.iHash.digestInto(out);
		this.oHash.update(out);
		this.oHash.digestInto(out);
		this.destroy();
	}
	digest() {
		const out = new Uint8Array(this.oHash.outputLen);
		this.digestInto(out);
		return out;
	}
	_cloneInto(to) {
		to || (to = Object.create(Object.getPrototypeOf(this), {}));
		const { oHash, iHash, finished, destroyed, blockLen, outputLen } = this;
		to = to;
		to.finished = finished;
		to.destroyed = destroyed;
		to.blockLen = blockLen;
		to.outputLen = outputLen;
		to.oHash = oHash._cloneInto(to.oHash);
		to.iHash = iHash._cloneInto(to.iHash);
		return to;
	}
	destroy() {
		this.destroyed = true;
		this.oHash.destroy();
		this.iHash.destroy();
	}
};
/**
* HMAC: RFC2104 message authentication code.
* @param hash - function that would be used e.g. sha256
* @param key - message key
* @param message - message data
* @example
* import { hmac } from '@noble/hashes/hmac';
* import { sha256 } from '@noble/hashes/sha2';
* const mac1 = hmac(sha256, 'key', 'message');
*/
var hmac = (hash, key, message) => new HMAC(hash, key).update(message).digest();
hmac.create = (hash, key) => new HMAC(hash, key);
//#endregion
//#region node_modules/@noble/curves/esm/abstract/utils.js
var utils_exports = /* @__PURE__ */ __exportAll({
	aInRange: () => aInRange,
	abool: () => abool,
	abytes: () => abytes,
	bitGet: () => bitGet,
	bitLen: () => bitLen,
	bitMask: () => bitMask,
	bitSet: () => bitSet,
	bytesToHex: () => bytesToHex$1,
	bytesToNumberBE: () => bytesToNumberBE,
	bytesToNumberLE: () => bytesToNumberLE,
	concatBytes: () => concatBytes,
	createHmacDrbg: () => createHmacDrbg,
	ensureBytes: () => ensureBytes,
	equalBytes: () => equalBytes,
	hexToBytes: () => hexToBytes$1,
	hexToNumber: () => hexToNumber,
	inRange: () => inRange,
	isBytes: () => isBytes,
	memoized: () => memoized,
	notImplemented: () => notImplemented,
	numberToBytesBE: () => numberToBytesBE,
	numberToBytesLE: () => numberToBytesLE,
	numberToHexUnpadded: () => numberToHexUnpadded,
	numberToVarBytesBE: () => numberToVarBytesBE,
	utf8ToBytes: () => utf8ToBytes,
	validateObject: () => validateObject
});
/*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
var _0n$5 = /* @__PURE__ */ BigInt(0);
var _1n$7 = /* @__PURE__ */ BigInt(1);
var _2n$5 = /* @__PURE__ */ BigInt(2);
function isBytes(a) {
	return a instanceof Uint8Array || a != null && typeof a === "object" && a.constructor.name === "Uint8Array";
}
function abytes(item) {
	if (!isBytes(item)) throw new Error("Uint8Array expected");
}
function abool(title, value) {
	if (typeof value !== "boolean") throw new Error(`${title} must be valid boolean, got "${value}".`);
}
var hexes = /* @__PURE__ */ Array.from({ length: 256 }, (_, i) => i.toString(16).padStart(2, "0"));
/**
* @example bytesToHex(Uint8Array.from([0xca, 0xfe, 0x01, 0x23])) // 'cafe0123'
*/
function bytesToHex$1(bytes) {
	abytes(bytes);
	let hex = "";
	for (let i = 0; i < bytes.length; i++) hex += hexes[bytes[i]];
	return hex;
}
function numberToHexUnpadded(num) {
	const hex = num.toString(16);
	return hex.length & 1 ? `0${hex}` : hex;
}
function hexToNumber(hex) {
	if (typeof hex !== "string") throw new Error("hex string expected, got " + typeof hex);
	return BigInt(hex === "" ? "0" : `0x${hex}`);
}
var asciis = {
	_0: 48,
	_9: 57,
	_A: 65,
	_F: 70,
	_a: 97,
	_f: 102
};
function asciiToBase16(char) {
	if (char >= asciis._0 && char <= asciis._9) return char - asciis._0;
	if (char >= asciis._A && char <= asciis._F) return char - (asciis._A - 10);
	if (char >= asciis._a && char <= asciis._f) return char - (asciis._a - 10);
}
/**
* @example hexToBytes('cafe0123') // Uint8Array.from([0xca, 0xfe, 0x01, 0x23])
*/
function hexToBytes$1(hex) {
	if (typeof hex !== "string") throw new Error("hex string expected, got " + typeof hex);
	const hl = hex.length;
	const al = hl / 2;
	if (hl % 2) throw new Error("padded hex string expected, got unpadded hex of length " + hl);
	const array = new Uint8Array(al);
	for (let ai = 0, hi = 0; ai < al; ai++, hi += 2) {
		const n1 = asciiToBase16(hex.charCodeAt(hi));
		const n2 = asciiToBase16(hex.charCodeAt(hi + 1));
		if (n1 === void 0 || n2 === void 0) {
			const char = hex[hi] + hex[hi + 1];
			throw new Error("hex string expected, got non-hex character \"" + char + "\" at index " + hi);
		}
		array[ai] = n1 * 16 + n2;
	}
	return array;
}
function bytesToNumberBE(bytes) {
	return hexToNumber(bytesToHex$1(bytes));
}
function bytesToNumberLE(bytes) {
	abytes(bytes);
	return hexToNumber(bytesToHex$1(Uint8Array.from(bytes).reverse()));
}
function numberToBytesBE(n, len) {
	return hexToBytes$1(n.toString(16).padStart(len * 2, "0"));
}
function numberToBytesLE(n, len) {
	return numberToBytesBE(n, len).reverse();
}
function numberToVarBytesBE(n) {
	return hexToBytes$1(numberToHexUnpadded(n));
}
/**
* Takes hex string or Uint8Array, converts to Uint8Array.
* Validates output length.
* Will throw error for other types.
* @param title descriptive title for an error e.g. 'private key'
* @param hex hex string or Uint8Array
* @param expectedLength optional, will compare to result array's length
* @returns
*/
function ensureBytes(title, hex, expectedLength) {
	let res;
	if (typeof hex === "string") try {
		res = hexToBytes$1(hex);
	} catch (e) {
		throw new Error(`${title} must be valid hex string, got "${hex}". Cause: ${e}`);
	}
	else if (isBytes(hex)) res = Uint8Array.from(hex);
	else throw new Error(`${title} must be hex string or Uint8Array`);
	const len = res.length;
	if (typeof expectedLength === "number" && len !== expectedLength) throw new Error(`${title} expected ${expectedLength} bytes, got ${len}`);
	return res;
}
/**
* Copies several Uint8Arrays into one.
*/
function concatBytes(...arrays) {
	let sum = 0;
	for (let i = 0; i < arrays.length; i++) {
		const a = arrays[i];
		abytes(a);
		sum += a.length;
	}
	const res = new Uint8Array(sum);
	for (let i = 0, pad = 0; i < arrays.length; i++) {
		const a = arrays[i];
		res.set(a, pad);
		pad += a.length;
	}
	return res;
}
function equalBytes(a, b) {
	if (a.length !== b.length) return false;
	let diff = 0;
	for (let i = 0; i < a.length; i++) diff |= a[i] ^ b[i];
	return diff === 0;
}
/**
* @example utf8ToBytes('abc') // new Uint8Array([97, 98, 99])
*/
function utf8ToBytes(str) {
	if (typeof str !== "string") throw new Error(`utf8ToBytes expected string, got ${typeof str}`);
	return new Uint8Array(new TextEncoder().encode(str));
}
var isPosBig = (n) => typeof n === "bigint" && _0n$5 <= n;
function inRange(n, min, max) {
	return isPosBig(n) && isPosBig(min) && isPosBig(max) && min <= n && n < max;
}
/**
* Asserts min <= n < max. NOTE: It's < max and not <= max.
* @example
* aInRange('x', x, 1n, 256n); // would assume x is in (1n..255n)
*/
function aInRange(title, n, min, max) {
	if (!inRange(n, min, max)) throw new Error(`expected valid ${title}: ${min} <= n < ${max}, got ${typeof n} ${n}`);
}
/**
* Calculates amount of bits in a bigint.
* Same as `n.toString(2).length`
*/
function bitLen(n) {
	let len;
	for (len = 0; n > _0n$5; n >>= _1n$7, len += 1);
	return len;
}
/**
* Gets single bit at position.
* NOTE: first bit position is 0 (same as arrays)
* Same as `!!+Array.from(n.toString(2)).reverse()[pos]`
*/
function bitGet(n, pos) {
	return n >> BigInt(pos) & _1n$7;
}
/**
* Sets single bit at position.
*/
function bitSet(n, pos, value) {
	return n | (value ? _1n$7 : _0n$5) << BigInt(pos);
}
/**
* Calculate mask for N bits. Not using ** operator with bigints because of old engines.
* Same as BigInt(`0b${Array(i).fill('1').join('')}`)
*/
var bitMask = (n) => (_2n$5 << BigInt(n - 1)) - _1n$7;
var u8n = (data) => new Uint8Array(data);
var u8fr = (arr) => Uint8Array.from(arr);
/**
* Minimal HMAC-DRBG from NIST 800-90 for RFC6979 sigs.
* @returns function that will call DRBG until 2nd arg returns something meaningful
* @example
*   const drbg = createHmacDRBG<Key>(32, 32, hmac);
*   drbg(seed, bytesToKey); // bytesToKey must return Key or undefined
*/
function createHmacDrbg(hashLen, qByteLen, hmacFn) {
	if (typeof hashLen !== "number" || hashLen < 2) throw new Error("hashLen must be a number");
	if (typeof qByteLen !== "number" || qByteLen < 2) throw new Error("qByteLen must be a number");
	if (typeof hmacFn !== "function") throw new Error("hmacFn must be a function");
	let v = u8n(hashLen);
	let k = u8n(hashLen);
	let i = 0;
	const reset = () => {
		v.fill(1);
		k.fill(0);
		i = 0;
	};
	const h = (...b) => hmacFn(k, v, ...b);
	const reseed = (seed = u8n()) => {
		k = h(u8fr([0]), seed);
		v = h();
		if (seed.length === 0) return;
		k = h(u8fr([1]), seed);
		v = h();
	};
	const gen = () => {
		if (i++ >= 1e3) throw new Error("drbg: tried 1000 values");
		let len = 0;
		const out = [];
		while (len < qByteLen) {
			v = h();
			const sl = v.slice();
			out.push(sl);
			len += v.length;
		}
		return concatBytes(...out);
	};
	const genUntil = (seed, pred) => {
		reset();
		reseed(seed);
		let res = void 0;
		while (!(res = pred(gen()))) reseed();
		reset();
		return res;
	};
	return genUntil;
}
var validatorFns = {
	bigint: (val) => typeof val === "bigint",
	function: (val) => typeof val === "function",
	boolean: (val) => typeof val === "boolean",
	string: (val) => typeof val === "string",
	stringOrUint8Array: (val) => typeof val === "string" || isBytes(val),
	isSafeInteger: (val) => Number.isSafeInteger(val),
	array: (val) => Array.isArray(val),
	field: (val, object) => object.Fp.isValid(val),
	hash: (val) => typeof val === "function" && Number.isSafeInteger(val.outputLen)
};
function validateObject(object, validators, optValidators = {}) {
	const checkField = (fieldName, type, isOptional) => {
		const checkVal = validatorFns[type];
		if (typeof checkVal !== "function") throw new Error(`Invalid validator "${type}", expected function`);
		const val = object[fieldName];
		if (isOptional && val === void 0) return;
		if (!checkVal(val, object)) throw new Error(`Invalid param ${String(fieldName)}=${val} (${typeof val}), expected ${type}`);
	};
	for (const [fieldName, type] of Object.entries(validators)) checkField(fieldName, type, false);
	for (const [fieldName, type] of Object.entries(optValidators)) checkField(fieldName, type, true);
	return object;
}
/**
* throws not implemented error
*/
var notImplemented = () => {
	throw new Error("not implemented");
};
/**
* Memoizes (caches) computation result.
* Uses WeakMap: the value is going auto-cleaned by GC after last reference is removed.
*/
function memoized(fn) {
	const map = /* @__PURE__ */ new WeakMap();
	return (arg, ...args) => {
		const val = map.get(arg);
		if (val !== void 0) return val;
		const computed = fn(arg, ...args);
		map.set(arg, computed);
		return computed;
	};
}
//#endregion
//#region node_modules/@noble/curves/esm/abstract/modular.js
/*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
var _0n$4 = BigInt(0);
var _1n$6 = BigInt(1);
var _2n$4 = BigInt(2);
var _3n$1 = BigInt(3);
var _4n = BigInt(4);
var _5n$1 = BigInt(5);
var _8n$2 = BigInt(8);
var _9n = BigInt(9);
var _16n = BigInt(16);
function mod(a, b) {
	const result = a % b;
	return result >= _0n$4 ? result : b + result;
}
/**
* Efficiently raise num to power and do modular division.
* Unsafe in some contexts: uses ladder, so can expose bigint bits.
* @example
* pow(2n, 6n, 11n) // 64n % 11n == 9n
*/
function pow(num, power, modulo) {
	if (modulo <= _0n$4 || power < _0n$4) throw new Error("Expected power/modulo > 0");
	if (modulo === _1n$6) return _0n$4;
	let res = _1n$6;
	while (power > _0n$4) {
		if (power & _1n$6) res = res * num % modulo;
		num = num * num % modulo;
		power >>= _1n$6;
	}
	return res;
}
function pow2(x, power, modulo) {
	let res = x;
	while (power-- > _0n$4) {
		res *= res;
		res %= modulo;
	}
	return res;
}
function invert(number, modulo) {
	if (number === _0n$4 || modulo <= _0n$4) throw new Error(`invert: expected positive integers, got n=${number} mod=${modulo}`);
	let a = mod(number, modulo);
	let b = modulo;
	let x = _0n$4, y = _1n$6, u = _1n$6, v = _0n$4;
	while (a !== _0n$4) {
		const q = b / a;
		const r = b % a;
		const m = x - u * q;
		const n = y - v * q;
		b = a, a = r, x = u, y = v, u = m, v = n;
	}
	if (b !== _1n$6) throw new Error("invert: does not exist");
	return mod(x, modulo);
}
/**
* Tonelli-Shanks square root search algorithm.
* 1. https://eprint.iacr.org/2012/685.pdf (page 12)
* 2. Square Roots from 1; 24, 51, 10 to Dan Shanks
* Will start an infinite loop if field order P is not prime.
* @param P field order
* @returns function that takes field Fp (created from P) and number n
*/
function tonelliShanks(P) {
	const legendreC = (P - _1n$6) / _2n$4;
	let Q, S, Z;
	for (Q = P - _1n$6, S = 0; Q % _2n$4 === _0n$4; Q /= _2n$4, S++);
	for (Z = _2n$4; Z < P && pow(Z, legendreC, P) !== P - _1n$6; Z++);
	if (S === 1) {
		const p1div4 = (P + _1n$6) / _4n;
		return function tonelliFast(Fp, n) {
			const root = Fp.pow(n, p1div4);
			if (!Fp.eql(Fp.sqr(root), n)) throw new Error("Cannot find square root");
			return root;
		};
	}
	const Q1div2 = (Q + _1n$6) / _2n$4;
	return function tonelliSlow(Fp, n) {
		if (Fp.pow(n, legendreC) === Fp.neg(Fp.ONE)) throw new Error("Cannot find square root");
		let r = S;
		let g = Fp.pow(Fp.mul(Fp.ONE, Z), Q);
		let x = Fp.pow(n, Q1div2);
		let b = Fp.pow(n, Q);
		while (!Fp.eql(b, Fp.ONE)) {
			if (Fp.eql(b, Fp.ZERO)) return Fp.ZERO;
			let m = 1;
			for (let t2 = Fp.sqr(b); m < r; m++) {
				if (Fp.eql(t2, Fp.ONE)) break;
				t2 = Fp.sqr(t2);
			}
			const ge = Fp.pow(g, _1n$6 << BigInt(r - m - 1));
			g = Fp.sqr(ge);
			x = Fp.mul(x, ge);
			b = Fp.mul(b, g);
			r = m;
		}
		return x;
	};
}
function FpSqrt(P) {
	if (P % _4n === _3n$1) {
		const p1div4 = (P + _1n$6) / _4n;
		return function sqrt3mod4(Fp, n) {
			const root = Fp.pow(n, p1div4);
			if (!Fp.eql(Fp.sqr(root), n)) throw new Error("Cannot find square root");
			return root;
		};
	}
	if (P % _8n$2 === _5n$1) {
		const c1 = (P - _5n$1) / _8n$2;
		return function sqrt5mod8(Fp, n) {
			const n2 = Fp.mul(n, _2n$4);
			const v = Fp.pow(n2, c1);
			const nv = Fp.mul(n, v);
			const i = Fp.mul(Fp.mul(nv, _2n$4), v);
			const root = Fp.mul(nv, Fp.sub(i, Fp.ONE));
			if (!Fp.eql(Fp.sqr(root), n)) throw new Error("Cannot find square root");
			return root;
		};
	}
	if (P % _16n === _9n) {}
	return tonelliShanks(P);
}
var isNegativeLE = (num, modulo) => (mod(num, modulo) & _1n$6) === _1n$6;
var FIELD_FIELDS = [
	"create",
	"isValid",
	"is0",
	"neg",
	"inv",
	"sqrt",
	"sqr",
	"eql",
	"add",
	"sub",
	"mul",
	"pow",
	"div",
	"addN",
	"subN",
	"mulN",
	"sqrN"
];
function validateField(field) {
	return validateObject(field, FIELD_FIELDS.reduce((map, val) => {
		map[val] = "function";
		return map;
	}, {
		ORDER: "bigint",
		MASK: "bigint",
		BYTES: "isSafeInteger",
		BITS: "isSafeInteger"
	}));
}
/**
* Same as `pow` but for Fp: non-constant-time.
* Unsafe in some contexts: uses ladder, so can expose bigint bits.
*/
function FpPow(f, num, power) {
	if (power < _0n$4) throw new Error("Expected power > 0");
	if (power === _0n$4) return f.ONE;
	if (power === _1n$6) return num;
	let p = f.ONE;
	let d = num;
	while (power > _0n$4) {
		if (power & _1n$6) p = f.mul(p, d);
		d = f.sqr(d);
		power >>= _1n$6;
	}
	return p;
}
/**
* Efficiently invert an array of Field elements.
* `inv(0)` will return `undefined` here: make sure to throw an error.
*/
function FpInvertBatch(f, nums) {
	const tmp = new Array(nums.length);
	const lastMultiplied = nums.reduce((acc, num, i) => {
		if (f.is0(num)) return acc;
		tmp[i] = acc;
		return f.mul(acc, num);
	}, f.ONE);
	const inverted = f.inv(lastMultiplied);
	nums.reduceRight((acc, num, i) => {
		if (f.is0(num)) return acc;
		tmp[i] = f.mul(acc, tmp[i]);
		return f.mul(acc, num);
	}, inverted);
	return tmp;
}
function nLength(n, nBitLength) {
	const _nBitLength = nBitLength !== void 0 ? nBitLength : n.toString(2).length;
	return {
		nBitLength: _nBitLength,
		nByteLength: Math.ceil(_nBitLength / 8)
	};
}
/**
* Initializes a finite field over prime. **Non-primes are not supported.**
* Do not init in loop: slow. Very fragile: always run a benchmark on a change.
* Major performance optimizations:
* * a) denormalized operations like mulN instead of mul
* * b) same object shape: never add or remove keys
* * c) Object.freeze
* NOTE: operations don't check 'isValid' for all elements for performance reasons,
* it is caller responsibility to check this.
* This is low-level code, please make sure you know what you doing.
* @param ORDER prime positive bigint
* @param bitLen how many bits the field consumes
* @param isLE (def: false) if encoding / decoding should be in little-endian
* @param redef optional faster redefinitions of sqrt and other methods
*/
function Field(ORDER, bitLen, isLE = false, redef = {}) {
	if (ORDER <= _0n$4) throw new Error(`Expected Field ORDER > 0, got ${ORDER}`);
	const { nBitLength: BITS, nByteLength: BYTES } = nLength(ORDER, bitLen);
	if (BYTES > 2048) throw new Error("Field lengths over 2048 bytes are not supported");
	const sqrtP = FpSqrt(ORDER);
	const f = Object.freeze({
		ORDER,
		BITS,
		BYTES,
		MASK: bitMask(BITS),
		ZERO: _0n$4,
		ONE: _1n$6,
		create: (num) => mod(num, ORDER),
		isValid: (num) => {
			if (typeof num !== "bigint") throw new Error(`Invalid field element: expected bigint, got ${typeof num}`);
			return _0n$4 <= num && num < ORDER;
		},
		is0: (num) => num === _0n$4,
		isOdd: (num) => (num & _1n$6) === _1n$6,
		neg: (num) => mod(-num, ORDER),
		eql: (lhs, rhs) => lhs === rhs,
		sqr: (num) => mod(num * num, ORDER),
		add: (lhs, rhs) => mod(lhs + rhs, ORDER),
		sub: (lhs, rhs) => mod(lhs - rhs, ORDER),
		mul: (lhs, rhs) => mod(lhs * rhs, ORDER),
		pow: (num, power) => FpPow(f, num, power),
		div: (lhs, rhs) => mod(lhs * invert(rhs, ORDER), ORDER),
		sqrN: (num) => num * num,
		addN: (lhs, rhs) => lhs + rhs,
		subN: (lhs, rhs) => lhs - rhs,
		mulN: (lhs, rhs) => lhs * rhs,
		inv: (num) => invert(num, ORDER),
		sqrt: redef.sqrt || ((n) => sqrtP(f, n)),
		invertBatch: (lst) => FpInvertBatch(f, lst),
		cmov: (a, b, c) => c ? b : a,
		toBytes: (num) => isLE ? numberToBytesLE(num, BYTES) : numberToBytesBE(num, BYTES),
		fromBytes: (bytes) => {
			if (bytes.length !== BYTES) throw new Error(`Fp.fromBytes: expected ${BYTES}, got ${bytes.length}`);
			return isLE ? bytesToNumberLE(bytes) : bytesToNumberBE(bytes);
		}
	});
	return Object.freeze(f);
}
/**
* Returns total number of bytes consumed by the field element.
* For example, 32 bytes for usual 256-bit weierstrass curve.
* @param fieldOrder number of field elements, usually CURVE.n
* @returns byte length of field
*/
function getFieldBytesLength(fieldOrder) {
	if (typeof fieldOrder !== "bigint") throw new Error("field order must be bigint");
	const bitLength = fieldOrder.toString(2).length;
	return Math.ceil(bitLength / 8);
}
/**
* Returns minimal amount of bytes that can be safely reduced
* by field order.
* Should be 2^-128 for 128-bit curve such as P256.
* @param fieldOrder number of field elements, usually CURVE.n
* @returns byte length of target hash
*/
function getMinHashLength(fieldOrder) {
	const length = getFieldBytesLength(fieldOrder);
	return length + Math.ceil(length / 2);
}
/**
* "Constant-time" private key generation utility.
* Can take (n + n/2) or more bytes of uniform input e.g. from CSPRNG or KDF
* and convert them into private scalar, with the modulo bias being negligible.
* Needs at least 48 bytes of input for 32-byte private key.
* https://research.kudelskisecurity.com/2020/07/28/the-definitive-guide-to-modulo-bias-and-how-to-avoid-it/
* FIPS 186-5, A.2 https://csrc.nist.gov/publications/detail/fips/186/5/final
* RFC 9380, https://www.rfc-editor.org/rfc/rfc9380#section-5
* @param hash hash output from SHA3 or a similar function
* @param groupOrder size of subgroup - (e.g. secp256k1.CURVE.n)
* @param isLE interpret hash bytes as LE num
* @returns valid private scalar
*/
function mapHashToField(key, fieldOrder, isLE = false) {
	const len = key.length;
	const fieldLen = getFieldBytesLength(fieldOrder);
	const minLen = getMinHashLength(fieldOrder);
	if (len < 16 || len < minLen || len > 1024) throw new Error(`expected ${minLen}-1024 bytes of input, got ${len}`);
	const reduced = mod(isLE ? bytesToNumberBE(key) : bytesToNumberLE(key), fieldOrder - _1n$6) + _1n$6;
	return isLE ? numberToBytesLE(reduced, fieldLen) : numberToBytesBE(reduced, fieldLen);
}
//#endregion
//#region node_modules/@noble/curves/esm/abstract/curve.js
/*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
var _0n$3 = BigInt(0);
var _1n$5 = BigInt(1);
var pointPrecomputes = /* @__PURE__ */ new WeakMap();
var pointWindowSizes = /* @__PURE__ */ new WeakMap();
function wNAF(c, bits) {
	const constTimeNegate = (condition, item) => {
		const neg = item.negate();
		return condition ? neg : item;
	};
	const validateW = (W) => {
		if (!Number.isSafeInteger(W) || W <= 0 || W > bits) throw new Error(`Wrong window size=${W}, should be [1..${bits}]`);
	};
	const opts = (W) => {
		validateW(W);
		return {
			windows: Math.ceil(bits / W) + 1,
			windowSize: 2 ** (W - 1)
		};
	};
	return {
		constTimeNegate,
		unsafeLadder(elm, n) {
			let p = c.ZERO;
			let d = elm;
			while (n > _0n$3) {
				if (n & _1n$5) p = p.add(d);
				d = d.double();
				n >>= _1n$5;
			}
			return p;
		},
		/**
		* Creates a wNAF precomputation window. Used for caching.
		* Default window size is set by `utils.precompute()` and is equal to 8.
		* Number of precomputed points depends on the curve size:
		* 2^(𝑊−1) * (Math.ceil(𝑛 / 𝑊) + 1), where:
		* - 𝑊 is the window size
		* - 𝑛 is the bitlength of the curve order.
		* For a 256-bit curve and window size 8, the number of precomputed points is 128 * 33 = 4224.
		* @returns precomputed point tables flattened to a single array
		*/
		precomputeWindow(elm, W) {
			const { windows, windowSize } = opts(W);
			const points = [];
			let p = elm;
			let base = p;
			for (let window = 0; window < windows; window++) {
				base = p;
				points.push(base);
				for (let i = 1; i < windowSize; i++) {
					base = base.add(p);
					points.push(base);
				}
				p = base.double();
			}
			return points;
		},
		/**
		* Implements ec multiplication using precomputed tables and w-ary non-adjacent form.
		* @param W window size
		* @param precomputes precomputed tables
		* @param n scalar (we don't check here, but should be less than curve order)
		* @returns real and fake (for const-time) points
		*/
		wNAF(W, precomputes, n) {
			const { windows, windowSize } = opts(W);
			let p = c.ZERO;
			let f = c.BASE;
			const mask = BigInt(2 ** W - 1);
			const maxNumber = 2 ** W;
			const shiftBy = BigInt(W);
			for (let window = 0; window < windows; window++) {
				const offset = window * windowSize;
				let wbits = Number(n & mask);
				n >>= shiftBy;
				if (wbits > windowSize) {
					wbits -= maxNumber;
					n += _1n$5;
				}
				const offset1 = offset;
				const offset2 = offset + Math.abs(wbits) - 1;
				const cond1 = window % 2 !== 0;
				const cond2 = wbits < 0;
				if (wbits === 0) f = f.add(constTimeNegate(cond1, precomputes[offset1]));
				else p = p.add(constTimeNegate(cond2, precomputes[offset2]));
			}
			return {
				p,
				f
			};
		},
		wNAFCached(P, n, transform) {
			const W = pointWindowSizes.get(P) || 1;
			let comp = pointPrecomputes.get(P);
			if (!comp) {
				comp = this.precomputeWindow(P, W);
				if (W !== 1) pointPrecomputes.set(P, transform(comp));
			}
			return this.wNAF(W, comp, n);
		},
		setWindowSize(P, W) {
			validateW(W);
			pointWindowSizes.set(P, W);
			pointPrecomputes.delete(P);
		}
	};
}
/**
* Pippenger algorithm for multi-scalar multiplication (MSM).
* MSM is basically (Pa + Qb + Rc + ...).
* 30x faster vs naive addition on L=4096, 10x faster with precomputes.
* For N=254bit, L=1, it does: 1024 ADD + 254 DBL. For L=5: 1536 ADD + 254 DBL.
* Algorithmically constant-time (for same L), even when 1 point + scalar, or when scalar = 0.
* @param c Curve Point constructor
* @param field field over CURVE.N - important that it's not over CURVE.P
* @param points array of L curve points
* @param scalars array of L scalars (aka private keys / bigints)
*/
function pippenger(c, field, points, scalars) {
	if (!Array.isArray(points) || !Array.isArray(scalars) || scalars.length !== points.length) throw new Error("arrays of points and scalars must have equal length");
	scalars.forEach((s, i) => {
		if (!field.isValid(s)) throw new Error(`wrong scalar at index ${i}`);
	});
	points.forEach((p, i) => {
		if (!(p instanceof c)) throw new Error(`wrong point at index ${i}`);
	});
	const wbits = bitLen(BigInt(points.length));
	const windowSize = wbits > 12 ? wbits - 3 : wbits > 4 ? wbits - 2 : wbits ? 2 : 1;
	const MASK = (1 << windowSize) - 1;
	const buckets = new Array(MASK + 1).fill(c.ZERO);
	const lastBits = Math.floor((field.BITS - 1) / windowSize) * windowSize;
	let sum = c.ZERO;
	for (let i = lastBits; i >= 0; i -= windowSize) {
		buckets.fill(c.ZERO);
		for (let j = 0; j < scalars.length; j++) {
			const scalar = scalars[j];
			const wbits = Number(scalar >> BigInt(i) & BigInt(MASK));
			buckets[wbits] = buckets[wbits].add(points[j]);
		}
		let resI = c.ZERO;
		for (let j = buckets.length - 1, sumI = c.ZERO; j > 0; j--) {
			sumI = sumI.add(buckets[j]);
			resI = resI.add(sumI);
		}
		sum = sum.add(resI);
		if (i !== 0) for (let j = 0; j < windowSize; j++) sum = sum.double();
	}
	return sum;
}
function validateBasic(curve) {
	validateField(curve.Fp);
	validateObject(curve, {
		n: "bigint",
		h: "bigint",
		Gx: "field",
		Gy: "field"
	}, {
		nBitLength: "isSafeInteger",
		nByteLength: "isSafeInteger"
	});
	return Object.freeze({
		...nLength(curve.n, curve.nBitLength),
		...curve,
		p: curve.Fp.ORDER
	});
}
//#endregion
//#region node_modules/@noble/curves/esm/abstract/weierstrass.js
/*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
function validateSigVerOpts(opts) {
	if (opts.lowS !== void 0) abool("lowS", opts.lowS);
	if (opts.prehash !== void 0) abool("prehash", opts.prehash);
}
function validatePointOpts(curve) {
	const opts = validateBasic(curve);
	validateObject(opts, {
		a: "field",
		b: "field"
	}, {
		allowedPrivateKeyLengths: "array",
		wrapPrivateKey: "boolean",
		isTorsionFree: "function",
		clearCofactor: "function",
		allowInfinityPoint: "boolean",
		fromBytes: "function",
		toBytes: "function"
	});
	const { endo, Fp, a } = opts;
	if (endo) {
		if (!Fp.eql(a, Fp.ZERO)) throw new Error("Endomorphism can only be defined for Koblitz curves that have a=0");
		if (typeof endo !== "object" || typeof endo.beta !== "bigint" || typeof endo.splitScalar !== "function") throw new Error("Expected endomorphism with beta: bigint and splitScalar: function");
	}
	return Object.freeze({ ...opts });
}
var { bytesToNumberBE: b2n, hexToBytes: h2b } = utils_exports;
/**
* ASN.1 DER encoding utilities. ASN is very complex & fragile. Format:
*
*     [0x30 (SEQUENCE), bytelength, 0x02 (INTEGER), intLength, R, 0x02 (INTEGER), intLength, S]
*
* Docs: https://letsencrypt.org/docs/a-warm-welcome-to-asn1-and-der/, https://luca.ntop.org/Teaching/Appunti/asn1.html
*/
var DER = {
	Err: class DERErr extends Error {
		constructor(m = "") {
			super(m);
		}
	},
	_tlv: {
		encode: (tag, data) => {
			const { Err: E } = DER;
			if (tag < 0 || tag > 256) throw new E("tlv.encode: wrong tag");
			if (data.length & 1) throw new E("tlv.encode: unpadded data");
			const dataLen = data.length / 2;
			const len = numberToHexUnpadded(dataLen);
			if (len.length / 2 & 128) throw new E("tlv.encode: long form length too big");
			const lenLen = dataLen > 127 ? numberToHexUnpadded(len.length / 2 | 128) : "";
			return `${numberToHexUnpadded(tag)}${lenLen}${len}${data}`;
		},
		decode(tag, data) {
			const { Err: E } = DER;
			let pos = 0;
			if (tag < 0 || tag > 256) throw new E("tlv.encode: wrong tag");
			if (data.length < 2 || data[pos++] !== tag) throw new E("tlv.decode: wrong tlv");
			const first = data[pos++];
			const isLong = !!(first & 128);
			let length = 0;
			if (!isLong) length = first;
			else {
				const lenLen = first & 127;
				if (!lenLen) throw new E("tlv.decode(long): indefinite length not supported");
				if (lenLen > 4) throw new E("tlv.decode(long): byte length is too big");
				const lengthBytes = data.subarray(pos, pos + lenLen);
				if (lengthBytes.length !== lenLen) throw new E("tlv.decode: length bytes not complete");
				if (lengthBytes[0] === 0) throw new E("tlv.decode(long): zero leftmost byte");
				for (const b of lengthBytes) length = length << 8 | b;
				pos += lenLen;
				if (length < 128) throw new E("tlv.decode(long): not minimal encoding");
			}
			const v = data.subarray(pos, pos + length);
			if (v.length !== length) throw new E("tlv.decode: wrong value length");
			return {
				v,
				l: data.subarray(pos + length)
			};
		}
	},
	_int: {
		encode(num) {
			const { Err: E } = DER;
			if (num < _0n$2) throw new E("integer: negative integers are not allowed");
			let hex = numberToHexUnpadded(num);
			if (Number.parseInt(hex[0], 16) & 8) hex = "00" + hex;
			if (hex.length & 1) throw new E("unexpected assertion");
			return hex;
		},
		decode(data) {
			const { Err: E } = DER;
			if (data[0] & 128) throw new E("Invalid signature integer: negative");
			if (data[0] === 0 && !(data[1] & 128)) throw new E("Invalid signature integer: unnecessary leading zero");
			return b2n(data);
		}
	},
	toSig(hex) {
		const { Err: E, _int: int, _tlv: tlv } = DER;
		const data = typeof hex === "string" ? h2b(hex) : hex;
		abytes(data);
		const { v: seqBytes, l: seqLeftBytes } = tlv.decode(48, data);
		if (seqLeftBytes.length) throw new E("Invalid signature: left bytes after parsing");
		const { v: rBytes, l: rLeftBytes } = tlv.decode(2, seqBytes);
		const { v: sBytes, l: sLeftBytes } = tlv.decode(2, rLeftBytes);
		if (sLeftBytes.length) throw new E("Invalid signature: left bytes after parsing");
		return {
			r: int.decode(rBytes),
			s: int.decode(sBytes)
		};
	},
	hexFromSig(sig) {
		const { _tlv: tlv, _int: int } = DER;
		const seq = `${tlv.encode(2, int.encode(sig.r))}${tlv.encode(2, int.encode(sig.s))}`;
		return tlv.encode(48, seq);
	}
};
var _0n$2 = BigInt(0);
var _1n$4 = BigInt(1);
var _3n = BigInt(3);
function weierstrassPoints(opts) {
	const CURVE = validatePointOpts(opts);
	const { Fp } = CURVE;
	const Fn = Field(CURVE.n, CURVE.nBitLength);
	const toBytes = CURVE.toBytes || ((_c, point, _isCompressed) => {
		const a = point.toAffine();
		return concatBytes(Uint8Array.from([4]), Fp.toBytes(a.x), Fp.toBytes(a.y));
	});
	const fromBytes = CURVE.fromBytes || ((bytes) => {
		const tail = bytes.subarray(1);
		return {
			x: Fp.fromBytes(tail.subarray(0, Fp.BYTES)),
			y: Fp.fromBytes(tail.subarray(Fp.BYTES, 2 * Fp.BYTES))
		};
	});
	/**
	* y² = x³ + ax + b: Short weierstrass curve formula
	* @returns y²
	*/
	function weierstrassEquation(x) {
		const { a, b } = CURVE;
		const x2 = Fp.sqr(x);
		const x3 = Fp.mul(x2, x);
		return Fp.add(Fp.add(x3, Fp.mul(x, a)), b);
	}
	if (!Fp.eql(Fp.sqr(CURVE.Gy), weierstrassEquation(CURVE.Gx))) throw new Error("bad generator point: equation left != right");
	function isWithinCurveOrder(num) {
		return inRange(num, _1n$4, CURVE.n);
	}
	function normPrivateKeyToScalar(key) {
		const { allowedPrivateKeyLengths: lengths, nByteLength, wrapPrivateKey, n: N } = CURVE;
		if (lengths && typeof key !== "bigint") {
			if (isBytes(key)) key = bytesToHex$1(key);
			if (typeof key !== "string" || !lengths.includes(key.length)) throw new Error("Invalid key");
			key = key.padStart(nByteLength * 2, "0");
		}
		let num;
		try {
			num = typeof key === "bigint" ? key : bytesToNumberBE(ensureBytes("private key", key, nByteLength));
		} catch (error) {
			throw new Error(`private key must be ${nByteLength} bytes, hex or bigint, not ${typeof key}`);
		}
		if (wrapPrivateKey) num = mod(num, N);
		aInRange("private key", num, _1n$4, N);
		return num;
	}
	function assertPrjPoint(other) {
		if (!(other instanceof Point)) throw new Error("ProjectivePoint expected");
	}
	const toAffineMemo = memoized((p, iz) => {
		const { px: x, py: y, pz: z } = p;
		if (Fp.eql(z, Fp.ONE)) return {
			x,
			y
		};
		const is0 = p.is0();
		if (iz == null) iz = is0 ? Fp.ONE : Fp.inv(z);
		const ax = Fp.mul(x, iz);
		const ay = Fp.mul(y, iz);
		const zz = Fp.mul(z, iz);
		if (is0) return {
			x: Fp.ZERO,
			y: Fp.ZERO
		};
		if (!Fp.eql(zz, Fp.ONE)) throw new Error("invZ was invalid");
		return {
			x: ax,
			y: ay
		};
	});
	const assertValidMemo = memoized((p) => {
		if (p.is0()) {
			if (CURVE.allowInfinityPoint && !Fp.is0(p.py)) return;
			throw new Error("bad point: ZERO");
		}
		const { x, y } = p.toAffine();
		if (!Fp.isValid(x) || !Fp.isValid(y)) throw new Error("bad point: x or y not FE");
		const left = Fp.sqr(y);
		const right = weierstrassEquation(x);
		if (!Fp.eql(left, right)) throw new Error("bad point: equation left != right");
		if (!p.isTorsionFree()) throw new Error("bad point: not in prime-order subgroup");
		return true;
	});
	/**
	* Projective Point works in 3d / projective (homogeneous) coordinates: (x, y, z) ∋ (x=x/z, y=y/z)
	* Default Point works in 2d / affine coordinates: (x, y)
	* We're doing calculations in projective, because its operations don't require costly inversion.
	*/
	class Point {
		constructor(px, py, pz) {
			this.px = px;
			this.py = py;
			this.pz = pz;
			if (px == null || !Fp.isValid(px)) throw new Error("x required");
			if (py == null || !Fp.isValid(py)) throw new Error("y required");
			if (pz == null || !Fp.isValid(pz)) throw new Error("z required");
			Object.freeze(this);
		}
		static fromAffine(p) {
			const { x, y } = p || {};
			if (!p || !Fp.isValid(x) || !Fp.isValid(y)) throw new Error("invalid affine point");
			if (p instanceof Point) throw new Error("projective point not allowed");
			const is0 = (i) => Fp.eql(i, Fp.ZERO);
			if (is0(x) && is0(y)) return Point.ZERO;
			return new Point(x, y, Fp.ONE);
		}
		get x() {
			return this.toAffine().x;
		}
		get y() {
			return this.toAffine().y;
		}
		/**
		* Takes a bunch of Projective Points but executes only one
		* inversion on all of them. Inversion is very slow operation,
		* so this improves performance massively.
		* Optimization: converts a list of projective points to a list of identical points with Z=1.
		*/
		static normalizeZ(points) {
			const toInv = Fp.invertBatch(points.map((p) => p.pz));
			return points.map((p, i) => p.toAffine(toInv[i])).map(Point.fromAffine);
		}
		/**
		* Converts hash string or Uint8Array to Point.
		* @param hex short/long ECDSA hex
		*/
		static fromHex(hex) {
			const P = Point.fromAffine(fromBytes(ensureBytes("pointHex", hex)));
			P.assertValidity();
			return P;
		}
		static fromPrivateKey(privateKey) {
			return Point.BASE.multiply(normPrivateKeyToScalar(privateKey));
		}
		static msm(points, scalars) {
			return pippenger(Point, Fn, points, scalars);
		}
		_setWindowSize(windowSize) {
			wnaf.setWindowSize(this, windowSize);
		}
		assertValidity() {
			assertValidMemo(this);
		}
		hasEvenY() {
			const { y } = this.toAffine();
			if (Fp.isOdd) return !Fp.isOdd(y);
			throw new Error("Field doesn't support isOdd");
		}
		/**
		* Compare one point to another.
		*/
		equals(other) {
			assertPrjPoint(other);
			const { px: X1, py: Y1, pz: Z1 } = this;
			const { px: X2, py: Y2, pz: Z2 } = other;
			const U1 = Fp.eql(Fp.mul(X1, Z2), Fp.mul(X2, Z1));
			const U2 = Fp.eql(Fp.mul(Y1, Z2), Fp.mul(Y2, Z1));
			return U1 && U2;
		}
		/**
		* Flips point to one corresponding to (x, -y) in Affine coordinates.
		*/
		negate() {
			return new Point(this.px, Fp.neg(this.py), this.pz);
		}
		double() {
			const { a, b } = CURVE;
			const b3 = Fp.mul(b, _3n);
			const { px: X1, py: Y1, pz: Z1 } = this;
			let X3 = Fp.ZERO, Y3 = Fp.ZERO, Z3 = Fp.ZERO;
			let t0 = Fp.mul(X1, X1);
			let t1 = Fp.mul(Y1, Y1);
			let t2 = Fp.mul(Z1, Z1);
			let t3 = Fp.mul(X1, Y1);
			t3 = Fp.add(t3, t3);
			Z3 = Fp.mul(X1, Z1);
			Z3 = Fp.add(Z3, Z3);
			X3 = Fp.mul(a, Z3);
			Y3 = Fp.mul(b3, t2);
			Y3 = Fp.add(X3, Y3);
			X3 = Fp.sub(t1, Y3);
			Y3 = Fp.add(t1, Y3);
			Y3 = Fp.mul(X3, Y3);
			X3 = Fp.mul(t3, X3);
			Z3 = Fp.mul(b3, Z3);
			t2 = Fp.mul(a, t2);
			t3 = Fp.sub(t0, t2);
			t3 = Fp.mul(a, t3);
			t3 = Fp.add(t3, Z3);
			Z3 = Fp.add(t0, t0);
			t0 = Fp.add(Z3, t0);
			t0 = Fp.add(t0, t2);
			t0 = Fp.mul(t0, t3);
			Y3 = Fp.add(Y3, t0);
			t2 = Fp.mul(Y1, Z1);
			t2 = Fp.add(t2, t2);
			t0 = Fp.mul(t2, t3);
			X3 = Fp.sub(X3, t0);
			Z3 = Fp.mul(t2, t1);
			Z3 = Fp.add(Z3, Z3);
			Z3 = Fp.add(Z3, Z3);
			return new Point(X3, Y3, Z3);
		}
		add(other) {
			assertPrjPoint(other);
			const { px: X1, py: Y1, pz: Z1 } = this;
			const { px: X2, py: Y2, pz: Z2 } = other;
			let X3 = Fp.ZERO, Y3 = Fp.ZERO, Z3 = Fp.ZERO;
			const a = CURVE.a;
			const b3 = Fp.mul(CURVE.b, _3n);
			let t0 = Fp.mul(X1, X2);
			let t1 = Fp.mul(Y1, Y2);
			let t2 = Fp.mul(Z1, Z2);
			let t3 = Fp.add(X1, Y1);
			let t4 = Fp.add(X2, Y2);
			t3 = Fp.mul(t3, t4);
			t4 = Fp.add(t0, t1);
			t3 = Fp.sub(t3, t4);
			t4 = Fp.add(X1, Z1);
			let t5 = Fp.add(X2, Z2);
			t4 = Fp.mul(t4, t5);
			t5 = Fp.add(t0, t2);
			t4 = Fp.sub(t4, t5);
			t5 = Fp.add(Y1, Z1);
			X3 = Fp.add(Y2, Z2);
			t5 = Fp.mul(t5, X3);
			X3 = Fp.add(t1, t2);
			t5 = Fp.sub(t5, X3);
			Z3 = Fp.mul(a, t4);
			X3 = Fp.mul(b3, t2);
			Z3 = Fp.add(X3, Z3);
			X3 = Fp.sub(t1, Z3);
			Z3 = Fp.add(t1, Z3);
			Y3 = Fp.mul(X3, Z3);
			t1 = Fp.add(t0, t0);
			t1 = Fp.add(t1, t0);
			t2 = Fp.mul(a, t2);
			t4 = Fp.mul(b3, t4);
			t1 = Fp.add(t1, t2);
			t2 = Fp.sub(t0, t2);
			t2 = Fp.mul(a, t2);
			t4 = Fp.add(t4, t2);
			t0 = Fp.mul(t1, t4);
			Y3 = Fp.add(Y3, t0);
			t0 = Fp.mul(t5, t4);
			X3 = Fp.mul(t3, X3);
			X3 = Fp.sub(X3, t0);
			t0 = Fp.mul(t3, t1);
			Z3 = Fp.mul(t5, Z3);
			Z3 = Fp.add(Z3, t0);
			return new Point(X3, Y3, Z3);
		}
		subtract(other) {
			return this.add(other.negate());
		}
		is0() {
			return this.equals(Point.ZERO);
		}
		wNAF(n) {
			return wnaf.wNAFCached(this, n, Point.normalizeZ);
		}
		/**
		* Non-constant-time multiplication. Uses double-and-add algorithm.
		* It's faster, but should only be used when you don't care about
		* an exposed private key e.g. sig verification, which works over *public* keys.
		*/
		multiplyUnsafe(sc) {
			aInRange("scalar", sc, _0n$2, CURVE.n);
			const I = Point.ZERO;
			if (sc === _0n$2) return I;
			if (sc === _1n$4) return this;
			const { endo } = CURVE;
			if (!endo) return wnaf.unsafeLadder(this, sc);
			let { k1neg, k1, k2neg, k2 } = endo.splitScalar(sc);
			let k1p = I;
			let k2p = I;
			let d = this;
			while (k1 > _0n$2 || k2 > _0n$2) {
				if (k1 & _1n$4) k1p = k1p.add(d);
				if (k2 & _1n$4) k2p = k2p.add(d);
				d = d.double();
				k1 >>= _1n$4;
				k2 >>= _1n$4;
			}
			if (k1neg) k1p = k1p.negate();
			if (k2neg) k2p = k2p.negate();
			k2p = new Point(Fp.mul(k2p.px, endo.beta), k2p.py, k2p.pz);
			return k1p.add(k2p);
		}
		/**
		* Constant time multiplication.
		* Uses wNAF method. Windowed method may be 10% faster,
		* but takes 2x longer to generate and consumes 2x memory.
		* Uses precomputes when available.
		* Uses endomorphism for Koblitz curves.
		* @param scalar by which the point would be multiplied
		* @returns New point
		*/
		multiply(scalar) {
			const { endo, n: N } = CURVE;
			aInRange("scalar", scalar, _1n$4, N);
			let point, fake;
			if (endo) {
				const { k1neg, k1, k2neg, k2 } = endo.splitScalar(scalar);
				let { p: k1p, f: f1p } = this.wNAF(k1);
				let { p: k2p, f: f2p } = this.wNAF(k2);
				k1p = wnaf.constTimeNegate(k1neg, k1p);
				k2p = wnaf.constTimeNegate(k2neg, k2p);
				k2p = new Point(Fp.mul(k2p.px, endo.beta), k2p.py, k2p.pz);
				point = k1p.add(k2p);
				fake = f1p.add(f2p);
			} else {
				const { p, f } = this.wNAF(scalar);
				point = p;
				fake = f;
			}
			return Point.normalizeZ([point, fake])[0];
		}
		/**
		* Efficiently calculate `aP + bQ`. Unsafe, can expose private key, if used incorrectly.
		* Not using Strauss-Shamir trick: precomputation tables are faster.
		* The trick could be useful if both P and Q are not G (not in our case).
		* @returns non-zero affine point
		*/
		multiplyAndAddUnsafe(Q, a, b) {
			const G = Point.BASE;
			const mul = (P, a) => a === _0n$2 || a === _1n$4 || !P.equals(G) ? P.multiplyUnsafe(a) : P.multiply(a);
			const sum = mul(this, a).add(mul(Q, b));
			return sum.is0() ? void 0 : sum;
		}
		toAffine(iz) {
			return toAffineMemo(this, iz);
		}
		isTorsionFree() {
			const { h: cofactor, isTorsionFree } = CURVE;
			if (cofactor === _1n$4) return true;
			if (isTorsionFree) return isTorsionFree(Point, this);
			throw new Error("isTorsionFree() has not been declared for the elliptic curve");
		}
		clearCofactor() {
			const { h: cofactor, clearCofactor } = CURVE;
			if (cofactor === _1n$4) return this;
			if (clearCofactor) return clearCofactor(Point, this);
			return this.multiplyUnsafe(CURVE.h);
		}
		toRawBytes(isCompressed = true) {
			abool("isCompressed", isCompressed);
			this.assertValidity();
			return toBytes(Point, this, isCompressed);
		}
		toHex(isCompressed = true) {
			abool("isCompressed", isCompressed);
			return bytesToHex$1(this.toRawBytes(isCompressed));
		}
	}
	Point.BASE = new Point(CURVE.Gx, CURVE.Gy, Fp.ONE);
	Point.ZERO = new Point(Fp.ZERO, Fp.ONE, Fp.ZERO);
	const _bits = CURVE.nBitLength;
	const wnaf = wNAF(Point, CURVE.endo ? Math.ceil(_bits / 2) : _bits);
	return {
		CURVE,
		ProjectivePoint: Point,
		normPrivateKeyToScalar,
		weierstrassEquation,
		isWithinCurveOrder
	};
}
function validateOpts$1(curve) {
	const opts = validateBasic(curve);
	validateObject(opts, {
		hash: "hash",
		hmac: "function",
		randomBytes: "function"
	}, {
		bits2int: "function",
		bits2int_modN: "function",
		lowS: "boolean"
	});
	return Object.freeze({
		lowS: true,
		...opts
	});
}
/**
* Creates short weierstrass curve and ECDSA signature methods for it.
* @example
* import { Field } from '@noble/curves/abstract/modular';
* // Before that, define BigInt-s: a, b, p, n, Gx, Gy
* const curve = weierstrass({ a, b, Fp: Field(p), n, Gx, Gy, h: 1n })
*/
function weierstrass(curveDef) {
	const CURVE = validateOpts$1(curveDef);
	const { Fp, n: CURVE_ORDER } = CURVE;
	const compressedLen = Fp.BYTES + 1;
	const uncompressedLen = 2 * Fp.BYTES + 1;
	function modN(a) {
		return mod(a, CURVE_ORDER);
	}
	function invN(a) {
		return invert(a, CURVE_ORDER);
	}
	const { ProjectivePoint: Point, normPrivateKeyToScalar, weierstrassEquation, isWithinCurveOrder } = weierstrassPoints({
		...CURVE,
		toBytes(_c, point, isCompressed) {
			const a = point.toAffine();
			const x = Fp.toBytes(a.x);
			const cat = concatBytes;
			abool("isCompressed", isCompressed);
			if (isCompressed) return cat(Uint8Array.from([point.hasEvenY() ? 2 : 3]), x);
			else return cat(Uint8Array.from([4]), x, Fp.toBytes(a.y));
		},
		fromBytes(bytes) {
			const len = bytes.length;
			const head = bytes[0];
			const tail = bytes.subarray(1);
			if (len === compressedLen && (head === 2 || head === 3)) {
				const x = bytesToNumberBE(tail);
				if (!inRange(x, _1n$4, Fp.ORDER)) throw new Error("Point is not on curve");
				const y2 = weierstrassEquation(x);
				let y;
				try {
					y = Fp.sqrt(y2);
				} catch (sqrtError) {
					const suffix = sqrtError instanceof Error ? ": " + sqrtError.message : "";
					throw new Error("Point is not on curve" + suffix);
				}
				const isYOdd = (y & _1n$4) === _1n$4;
				if ((head & 1) === 1 !== isYOdd) y = Fp.neg(y);
				return {
					x,
					y
				};
			} else if (len === uncompressedLen && head === 4) return {
				x: Fp.fromBytes(tail.subarray(0, Fp.BYTES)),
				y: Fp.fromBytes(tail.subarray(Fp.BYTES, 2 * Fp.BYTES))
			};
			else throw new Error(`Point of length ${len} was invalid. Expected ${compressedLen} compressed bytes or ${uncompressedLen} uncompressed bytes`);
		}
	});
	const numToNByteStr = (num) => bytesToHex$1(numberToBytesBE(num, CURVE.nByteLength));
	function isBiggerThanHalfOrder(number) {
		return number > CURVE_ORDER >> _1n$4;
	}
	function normalizeS(s) {
		return isBiggerThanHalfOrder(s) ? modN(-s) : s;
	}
	const slcNum = (b, from, to) => bytesToNumberBE(b.slice(from, to));
	/**
	* ECDSA signature with its (r, s) properties. Supports DER & compact representations.
	*/
	class Signature {
		constructor(r, s, recovery) {
			this.r = r;
			this.s = s;
			this.recovery = recovery;
			this.assertValidity();
		}
		static fromCompact(hex) {
			const l = CURVE.nByteLength;
			hex = ensureBytes("compactSignature", hex, l * 2);
			return new Signature(slcNum(hex, 0, l), slcNum(hex, l, 2 * l));
		}
		static fromDER(hex) {
			const { r, s } = DER.toSig(ensureBytes("DER", hex));
			return new Signature(r, s);
		}
		assertValidity() {
			aInRange("r", this.r, _1n$4, CURVE_ORDER);
			aInRange("s", this.s, _1n$4, CURVE_ORDER);
		}
		addRecoveryBit(recovery) {
			return new Signature(this.r, this.s, recovery);
		}
		recoverPublicKey(msgHash) {
			const { r, s, recovery: rec } = this;
			const h = bits2int_modN(ensureBytes("msgHash", msgHash));
			if (rec == null || ![
				0,
				1,
				2,
				3
			].includes(rec)) throw new Error("recovery id invalid");
			const radj = rec === 2 || rec === 3 ? r + CURVE.n : r;
			if (radj >= Fp.ORDER) throw new Error("recovery id 2 or 3 invalid");
			const prefix = (rec & 1) === 0 ? "02" : "03";
			const R = Point.fromHex(prefix + numToNByteStr(radj));
			const ir = invN(radj);
			const u1 = modN(-h * ir);
			const u2 = modN(s * ir);
			const Q = Point.BASE.multiplyAndAddUnsafe(R, u1, u2);
			if (!Q) throw new Error("point at infinify");
			Q.assertValidity();
			return Q;
		}
		hasHighS() {
			return isBiggerThanHalfOrder(this.s);
		}
		normalizeS() {
			return this.hasHighS() ? new Signature(this.r, modN(-this.s), this.recovery) : this;
		}
		toDERRawBytes() {
			return hexToBytes$1(this.toDERHex());
		}
		toDERHex() {
			return DER.hexFromSig({
				r: this.r,
				s: this.s
			});
		}
		toCompactRawBytes() {
			return hexToBytes$1(this.toCompactHex());
		}
		toCompactHex() {
			return numToNByteStr(this.r) + numToNByteStr(this.s);
		}
	}
	const utils = {
		isValidPrivateKey(privateKey) {
			try {
				normPrivateKeyToScalar(privateKey);
				return true;
			} catch (error) {
				return false;
			}
		},
		normPrivateKeyToScalar,
		/**
		* Produces cryptographically secure private key from random of size
		* (groupLen + ceil(groupLen / 2)) with modulo bias being negligible.
		*/
		randomPrivateKey: () => {
			const length = getMinHashLength(CURVE.n);
			return mapHashToField(CURVE.randomBytes(length), CURVE.n);
		},
		/**
		* Creates precompute table for an arbitrary EC point. Makes point "cached".
		* Allows to massively speed-up `point.multiply(scalar)`.
		* @returns cached point
		* @example
		* const fast = utils.precompute(8, ProjectivePoint.fromHex(someonesPubKey));
		* fast.multiply(privKey); // much faster ECDH now
		*/
		precompute(windowSize = 8, point = Point.BASE) {
			point._setWindowSize(windowSize);
			point.multiply(BigInt(3));
			return point;
		}
	};
	/**
	* Computes public key for a private key. Checks for validity of the private key.
	* @param privateKey private key
	* @param isCompressed whether to return compact (default), or full key
	* @returns Public key, full when isCompressed=false; short when isCompressed=true
	*/
	function getPublicKey(privateKey, isCompressed = true) {
		return Point.fromPrivateKey(privateKey).toRawBytes(isCompressed);
	}
	/**
	* Quick and dirty check for item being public key. Does not validate hex, or being on-curve.
	*/
	function isProbPub(item) {
		const arr = isBytes(item);
		const str = typeof item === "string";
		const len = (arr || str) && item.length;
		if (arr) return len === compressedLen || len === uncompressedLen;
		if (str) return len === 2 * compressedLen || len === 2 * uncompressedLen;
		if (item instanceof Point) return true;
		return false;
	}
	/**
	* ECDH (Elliptic Curve Diffie Hellman).
	* Computes shared public key from private key and public key.
	* Checks: 1) private key validity 2) shared key is on-curve.
	* Does NOT hash the result.
	* @param privateA private key
	* @param publicB different public key
	* @param isCompressed whether to return compact (default), or full key
	* @returns shared public key
	*/
	function getSharedSecret(privateA, publicB, isCompressed = true) {
		if (isProbPub(privateA)) throw new Error("first arg must be private key");
		if (!isProbPub(publicB)) throw new Error("second arg must be public key");
		return Point.fromHex(publicB).multiply(normPrivateKeyToScalar(privateA)).toRawBytes(isCompressed);
	}
	const bits2int = CURVE.bits2int || function(bytes) {
		const num = bytesToNumberBE(bytes);
		const delta = bytes.length * 8 - CURVE.nBitLength;
		return delta > 0 ? num >> BigInt(delta) : num;
	};
	const bits2int_modN = CURVE.bits2int_modN || function(bytes) {
		return modN(bits2int(bytes));
	};
	const ORDER_MASK = bitMask(CURVE.nBitLength);
	/**
	* Converts to bytes. Checks if num in `[0..ORDER_MASK-1]` e.g.: `[0..2^256-1]`.
	*/
	function int2octets(num) {
		aInRange(`num < 2^${CURVE.nBitLength}`, num, _0n$2, ORDER_MASK);
		return numberToBytesBE(num, CURVE.nByteLength);
	}
	function prepSig(msgHash, privateKey, opts = defaultSigOpts) {
		if (["recovered", "canonical"].some((k) => k in opts)) throw new Error("sign() legacy options not supported");
		const { hash, randomBytes } = CURVE;
		let { lowS, prehash, extraEntropy: ent } = opts;
		if (lowS == null) lowS = true;
		msgHash = ensureBytes("msgHash", msgHash);
		validateSigVerOpts(opts);
		if (prehash) msgHash = ensureBytes("prehashed msgHash", hash(msgHash));
		const h1int = bits2int_modN(msgHash);
		const d = normPrivateKeyToScalar(privateKey);
		const seedArgs = [int2octets(d), int2octets(h1int)];
		if (ent != null && ent !== false) {
			const e = ent === true ? randomBytes(Fp.BYTES) : ent;
			seedArgs.push(ensureBytes("extraEntropy", e));
		}
		const seed = concatBytes(...seedArgs);
		const m = h1int;
		function k2sig(kBytes) {
			const k = bits2int(kBytes);
			if (!isWithinCurveOrder(k)) return;
			const ik = invN(k);
			const q = Point.BASE.multiply(k).toAffine();
			const r = modN(q.x);
			if (r === _0n$2) return;
			const s = modN(ik * modN(m + r * d));
			if (s === _0n$2) return;
			let recovery = (q.x === r ? 0 : 2) | Number(q.y & _1n$4);
			let normS = s;
			if (lowS && isBiggerThanHalfOrder(s)) {
				normS = normalizeS(s);
				recovery ^= 1;
			}
			return new Signature(r, normS, recovery);
		}
		return {
			seed,
			k2sig
		};
	}
	const defaultSigOpts = {
		lowS: CURVE.lowS,
		prehash: false
	};
	const defaultVerOpts = {
		lowS: CURVE.lowS,
		prehash: false
	};
	/**
	* Signs message hash with a private key.
	* ```
	* sign(m, d, k) where
	*   (x, y) = G × k
	*   r = x mod n
	*   s = (m + dr)/k mod n
	* ```
	* @param msgHash NOT message. msg needs to be hashed to `msgHash`, or use `prehash`.
	* @param privKey private key
	* @param opts lowS for non-malleable sigs. extraEntropy for mixing randomness into k. prehash will hash first arg.
	* @returns signature with recovery param
	*/
	function sign(msgHash, privKey, opts = defaultSigOpts) {
		const { seed, k2sig } = prepSig(msgHash, privKey, opts);
		const C = CURVE;
		return createHmacDrbg(C.hash.outputLen, C.nByteLength, C.hmac)(seed, k2sig);
	}
	Point.BASE._setWindowSize(8);
	/**
	* Verifies a signature against message hash and public key.
	* Rejects lowS signatures by default: to override,
	* specify option `{lowS: false}`. Implements section 4.1.4 from https://www.secg.org/sec1-v2.pdf:
	*
	* ```
	* verify(r, s, h, P) where
	*   U1 = hs^-1 mod n
	*   U2 = rs^-1 mod n
	*   R = U1⋅G - U2⋅P
	*   mod(R.x, n) == r
	* ```
	*/
	function verify(signature, msgHash, publicKey, opts = defaultVerOpts) {
		const sg = signature;
		msgHash = ensureBytes("msgHash", msgHash);
		publicKey = ensureBytes("publicKey", publicKey);
		if ("strict" in opts) throw new Error("options.strict was renamed to lowS");
		validateSigVerOpts(opts);
		const { lowS, prehash } = opts;
		let _sig = void 0;
		let P;
		try {
			if (typeof sg === "string" || isBytes(sg)) try {
				_sig = Signature.fromDER(sg);
			} catch (derError) {
				if (!(derError instanceof DER.Err)) throw derError;
				_sig = Signature.fromCompact(sg);
			}
			else if (typeof sg === "object" && typeof sg.r === "bigint" && typeof sg.s === "bigint") {
				const { r, s } = sg;
				_sig = new Signature(r, s);
			} else throw new Error("PARSE");
			P = Point.fromHex(publicKey);
		} catch (error) {
			if (error.message === "PARSE") throw new Error(`signature must be Signature instance, Uint8Array or hex string`);
			return false;
		}
		if (lowS && _sig.hasHighS()) return false;
		if (prehash) msgHash = CURVE.hash(msgHash);
		const { r, s } = _sig;
		const h = bits2int_modN(msgHash);
		const is = invN(s);
		const u1 = modN(h * is);
		const u2 = modN(r * is);
		const R = Point.BASE.multiplyAndAddUnsafe(P, u1, u2)?.toAffine();
		if (!R) return false;
		return modN(R.x) === r;
	}
	return {
		CURVE,
		getPublicKey,
		getSharedSecret,
		sign,
		verify,
		ProjectivePoint: Point,
		Signature,
		utils
	};
}
//#endregion
//#region node_modules/@noble/curves/esm/_shortw_utils.js
/*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
function getHash(hash) {
	return {
		hash,
		hmac: (key, ...msgs) => hmac(hash, key, concatBytes$1(...msgs)),
		randomBytes
	};
}
function createCurve(curveDef, defHash) {
	const create = (hash) => weierstrass({
		...curveDef,
		...getHash(hash)
	});
	return Object.freeze({
		...create(defHash),
		create
	});
}
//#endregion
//#region node_modules/@noble/curves/esm/secp256k1.js
/*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
var secp256k1P = BigInt("0xfffffffffffffffffffffffffffffffffffffffffffffffffffffffefffffc2f");
var secp256k1N = BigInt("0xfffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141");
var _1n$3 = BigInt(1);
var _2n$3 = BigInt(2);
var divNearest = (a, b) => (a + b / _2n$3) / b;
/**
* √n = n^((p+1)/4) for fields p = 3 mod 4. We unwrap the loop and multiply bit-by-bit.
* (P+1n/4n).toString(2) would produce bits [223x 1, 0, 22x 1, 4x 0, 11, 00]
*/
function sqrtMod(y) {
	const P = secp256k1P;
	const _3n = BigInt(3), _6n = BigInt(6), _11n = BigInt(11), _22n = BigInt(22);
	const _23n = BigInt(23), _44n = BigInt(44), _88n = BigInt(88);
	const b2 = y * y * y % P;
	const b3 = b2 * b2 * y % P;
	const b11 = pow2(pow2(pow2(b3, _3n, P) * b3 % P, _3n, P) * b3 % P, _2n$3, P) * b2 % P;
	const b22 = pow2(b11, _11n, P) * b11 % P;
	const b44 = pow2(b22, _22n, P) * b22 % P;
	const b88 = pow2(b44, _44n, P) * b44 % P;
	const root = pow2(pow2(pow2(pow2(pow2(pow2(b88, _88n, P) * b88 % P, _44n, P) * b44 % P, _3n, P) * b3 % P, _23n, P) * b22 % P, _6n, P) * b2 % P, _2n$3, P);
	if (!Fp$1.eql(Fp$1.sqr(root), y)) throw new Error("Cannot find square root");
	return root;
}
var Fp$1 = Field(secp256k1P, void 0, void 0, { sqrt: sqrtMod });
/**
* secp256k1 short weierstrass curve and ECDSA signatures over it.
*/
var secp256k1 = createCurve({
	a: BigInt(0),
	b: BigInt(7),
	Fp: Fp$1,
	n: secp256k1N,
	Gx: BigInt("55066263022277343669578718895168534326250603453777594175500187360389116729240"),
	Gy: BigInt("32670510020758816978083085130507043184471273380659243275938904335757337482424"),
	h: BigInt(1),
	lowS: true,
	/**
	* secp256k1 belongs to Koblitz curves: it has efficiently computable endomorphism.
	* Endomorphism uses 2x less RAM, speeds up precomputation by 2x and ECDH / key recovery by 20%.
	* For precomputed wNAF it trades off 1/2 init time & 1/3 ram for 20% perf hit.
	* Explanation: https://gist.github.com/paulmillr/eb670806793e84df628a7c434a873066
	*/
	endo: {
		beta: BigInt("0x7ae96a2b657c07106e64479eac3434e99cf0497512f58995c1396c28719501ee"),
		splitScalar: (k) => {
			const n = secp256k1N;
			const a1 = BigInt("0x3086d221a7d46bcde86c90e49284eb15");
			const b1 = -_1n$3 * BigInt("0xe4437ed6010e88286f547fa90abfe4c3");
			const a2 = BigInt("0x114ca50f7a8e2f3f657c1108d9d44cfd8");
			const b2 = a1;
			const POW_2_128 = BigInt("0x100000000000000000000000000000000");
			const c1 = divNearest(b2 * k, n);
			const c2 = divNearest(-b1 * k, n);
			let k1 = mod(k - c1 * a1 - c2 * a2, n);
			let k2 = mod(-c1 * b1 - c2 * b2, n);
			const k1neg = k1 > POW_2_128;
			const k2neg = k2 > POW_2_128;
			if (k1neg) k1 = n - k1;
			if (k2neg) k2 = n - k2;
			if (k1 > POW_2_128 || k2 > POW_2_128) throw new Error("splitScalar: Endomorphism failed, k=" + k);
			return {
				k1neg,
				k1,
				k2neg,
				k2
			};
		}
	}
}, sha256);
secp256k1.ProjectivePoint;
//#endregion
//#region node_modules/@noble/hashes/esm/_u64.js
var U32_MASK64 = /* @__PURE__ */ BigInt(2 ** 32 - 1);
var _32n = /* @__PURE__ */ BigInt(32);
function fromBig(n, le = false) {
	if (le) return {
		h: Number(n & U32_MASK64),
		l: Number(n >> _32n & U32_MASK64)
	};
	return {
		h: Number(n >> _32n & U32_MASK64) | 0,
		l: Number(n & U32_MASK64) | 0
	};
}
function split(lst, le = false) {
	let Ah = new Uint32Array(lst.length);
	let Al = new Uint32Array(lst.length);
	for (let i = 0; i < lst.length; i++) {
		const { h, l } = fromBig(lst[i], le);
		[Ah[i], Al[i]] = [h, l];
	}
	return [Ah, Al];
}
var toBig = (h, l) => BigInt(h >>> 0) << _32n | BigInt(l >>> 0);
var shrSH = (h, _l, s) => h >>> s;
var shrSL = (h, l, s) => h << 32 - s | l >>> s;
var rotrSH = (h, l, s) => h >>> s | l << 32 - s;
var rotrSL = (h, l, s) => h << 32 - s | l >>> s;
var rotrBH = (h, l, s) => h << 64 - s | l >>> s - 32;
var rotrBL = (h, l, s) => h >>> s - 32 | l << 64 - s;
var rotr32H = (_h, l) => l;
var rotr32L = (h, _l) => h;
var rotlSH = (h, l, s) => h << s | l >>> 32 - s;
var rotlSL = (h, l, s) => l << s | h >>> 32 - s;
var rotlBH = (h, l, s) => l << s - 32 | h >>> 64 - s;
var rotlBL = (h, l, s) => h << s - 32 | l >>> 64 - s;
function add(Ah, Al, Bh, Bl) {
	const l = (Al >>> 0) + (Bl >>> 0);
	return {
		h: Ah + Bh + (l / 2 ** 32 | 0) | 0,
		l: l | 0
	};
}
var add3L = (Al, Bl, Cl) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0);
var add3H = (low, Ah, Bh, Ch) => Ah + Bh + Ch + (low / 2 ** 32 | 0) | 0;
var add4L = (Al, Bl, Cl, Dl) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0) + (Dl >>> 0);
var add4H = (low, Ah, Bh, Ch, Dh) => Ah + Bh + Ch + Dh + (low / 2 ** 32 | 0) | 0;
var add5L = (Al, Bl, Cl, Dl, El) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0) + (Dl >>> 0) + (El >>> 0);
var add5H = (low, Ah, Bh, Ch, Dh, Eh) => Ah + Bh + Ch + Dh + Eh + (low / 2 ** 32 | 0) | 0;
var u64 = {
	fromBig,
	split,
	toBig,
	shrSH,
	shrSL,
	rotrSH,
	rotrSL,
	rotrBH,
	rotrBL,
	rotr32H,
	rotr32L,
	rotlSH,
	rotlSL,
	rotlBH,
	rotlBL,
	add,
	add3L,
	add3H,
	add4L,
	add4H,
	add5H,
	add5L
};
//#endregion
//#region node_modules/@noble/hashes/esm/sha512.js
var [SHA512_Kh, SHA512_Kl] = /* @__PURE__ */ (() => u64.split([
	"0x428a2f98d728ae22",
	"0x7137449123ef65cd",
	"0xb5c0fbcfec4d3b2f",
	"0xe9b5dba58189dbbc",
	"0x3956c25bf348b538",
	"0x59f111f1b605d019",
	"0x923f82a4af194f9b",
	"0xab1c5ed5da6d8118",
	"0xd807aa98a3030242",
	"0x12835b0145706fbe",
	"0x243185be4ee4b28c",
	"0x550c7dc3d5ffb4e2",
	"0x72be5d74f27b896f",
	"0x80deb1fe3b1696b1",
	"0x9bdc06a725c71235",
	"0xc19bf174cf692694",
	"0xe49b69c19ef14ad2",
	"0xefbe4786384f25e3",
	"0x0fc19dc68b8cd5b5",
	"0x240ca1cc77ac9c65",
	"0x2de92c6f592b0275",
	"0x4a7484aa6ea6e483",
	"0x5cb0a9dcbd41fbd4",
	"0x76f988da831153b5",
	"0x983e5152ee66dfab",
	"0xa831c66d2db43210",
	"0xb00327c898fb213f",
	"0xbf597fc7beef0ee4",
	"0xc6e00bf33da88fc2",
	"0xd5a79147930aa725",
	"0x06ca6351e003826f",
	"0x142929670a0e6e70",
	"0x27b70a8546d22ffc",
	"0x2e1b21385c26c926",
	"0x4d2c6dfc5ac42aed",
	"0x53380d139d95b3df",
	"0x650a73548baf63de",
	"0x766a0abb3c77b2a8",
	"0x81c2c92e47edaee6",
	"0x92722c851482353b",
	"0xa2bfe8a14cf10364",
	"0xa81a664bbc423001",
	"0xc24b8b70d0f89791",
	"0xc76c51a30654be30",
	"0xd192e819d6ef5218",
	"0xd69906245565a910",
	"0xf40e35855771202a",
	"0x106aa07032bbd1b8",
	"0x19a4c116b8d2d0c8",
	"0x1e376c085141ab53",
	"0x2748774cdf8eeb99",
	"0x34b0bcb5e19b48a8",
	"0x391c0cb3c5c95a63",
	"0x4ed8aa4ae3418acb",
	"0x5b9cca4f7763e373",
	"0x682e6ff3d6b2b8a3",
	"0x748f82ee5defb2fc",
	"0x78a5636f43172f60",
	"0x84c87814a1f0ab72",
	"0x8cc702081a6439ec",
	"0x90befffa23631e28",
	"0xa4506cebde82bde9",
	"0xbef9a3f7b2c67915",
	"0xc67178f2e372532b",
	"0xca273eceea26619c",
	"0xd186b8c721c0c207",
	"0xeada7dd6cde0eb1e",
	"0xf57d4f7fee6ed178",
	"0x06f067aa72176fba",
	"0x0a637dc5a2c898a6",
	"0x113f9804bef90dae",
	"0x1b710b35131c471b",
	"0x28db77f523047d84",
	"0x32caab7b40c72493",
	"0x3c9ebe0a15c9bebc",
	"0x431d67c49c100d4c",
	"0x4cc5d4becb3e42b6",
	"0x597f299cfc657e2a",
	"0x5fcb6fab3ad6faec",
	"0x6c44198c4a475817"
].map((n) => BigInt(n))))();
var SHA512_W_H = /* @__PURE__ */ new Uint32Array(80);
var SHA512_W_L = /* @__PURE__ */ new Uint32Array(80);
var SHA512 = class extends HashMD {
	constructor() {
		super(128, 64, 16, false);
		this.Ah = 1779033703;
		this.Al = -205731576;
		this.Bh = -1150833019;
		this.Bl = -2067093701;
		this.Ch = 1013904242;
		this.Cl = -23791573;
		this.Dh = -1521486534;
		this.Dl = 1595750129;
		this.Eh = 1359893119;
		this.El = -1377402159;
		this.Fh = -1694144372;
		this.Fl = 725511199;
		this.Gh = 528734635;
		this.Gl = -79577749;
		this.Hh = 1541459225;
		this.Hl = 327033209;
	}
	get() {
		const { Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl } = this;
		return [
			Ah,
			Al,
			Bh,
			Bl,
			Ch,
			Cl,
			Dh,
			Dl,
			Eh,
			El,
			Fh,
			Fl,
			Gh,
			Gl,
			Hh,
			Hl
		];
	}
	set(Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl) {
		this.Ah = Ah | 0;
		this.Al = Al | 0;
		this.Bh = Bh | 0;
		this.Bl = Bl | 0;
		this.Ch = Ch | 0;
		this.Cl = Cl | 0;
		this.Dh = Dh | 0;
		this.Dl = Dl | 0;
		this.Eh = Eh | 0;
		this.El = El | 0;
		this.Fh = Fh | 0;
		this.Fl = Fl | 0;
		this.Gh = Gh | 0;
		this.Gl = Gl | 0;
		this.Hh = Hh | 0;
		this.Hl = Hl | 0;
	}
	process(view, offset) {
		for (let i = 0; i < 16; i++, offset += 4) {
			SHA512_W_H[i] = view.getUint32(offset);
			SHA512_W_L[i] = view.getUint32(offset += 4);
		}
		for (let i = 16; i < 80; i++) {
			const W15h = SHA512_W_H[i - 15] | 0;
			const W15l = SHA512_W_L[i - 15] | 0;
			const s0h = u64.rotrSH(W15h, W15l, 1) ^ u64.rotrSH(W15h, W15l, 8) ^ u64.shrSH(W15h, W15l, 7);
			const s0l = u64.rotrSL(W15h, W15l, 1) ^ u64.rotrSL(W15h, W15l, 8) ^ u64.shrSL(W15h, W15l, 7);
			const W2h = SHA512_W_H[i - 2] | 0;
			const W2l = SHA512_W_L[i - 2] | 0;
			const s1h = u64.rotrSH(W2h, W2l, 19) ^ u64.rotrBH(W2h, W2l, 61) ^ u64.shrSH(W2h, W2l, 6);
			const s1l = u64.rotrSL(W2h, W2l, 19) ^ u64.rotrBL(W2h, W2l, 61) ^ u64.shrSL(W2h, W2l, 6);
			const SUMl = u64.add4L(s0l, s1l, SHA512_W_L[i - 7], SHA512_W_L[i - 16]);
			SHA512_W_H[i] = u64.add4H(SUMl, s0h, s1h, SHA512_W_H[i - 7], SHA512_W_H[i - 16]) | 0;
			SHA512_W_L[i] = SUMl | 0;
		}
		let { Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl } = this;
		for (let i = 0; i < 80; i++) {
			const sigma1h = u64.rotrSH(Eh, El, 14) ^ u64.rotrSH(Eh, El, 18) ^ u64.rotrBH(Eh, El, 41);
			const sigma1l = u64.rotrSL(Eh, El, 14) ^ u64.rotrSL(Eh, El, 18) ^ u64.rotrBL(Eh, El, 41);
			const CHIh = Eh & Fh ^ ~Eh & Gh;
			const CHIl = El & Fl ^ ~El & Gl;
			const T1ll = u64.add5L(Hl, sigma1l, CHIl, SHA512_Kl[i], SHA512_W_L[i]);
			const T1h = u64.add5H(T1ll, Hh, sigma1h, CHIh, SHA512_Kh[i], SHA512_W_H[i]);
			const T1l = T1ll | 0;
			const sigma0h = u64.rotrSH(Ah, Al, 28) ^ u64.rotrBH(Ah, Al, 34) ^ u64.rotrBH(Ah, Al, 39);
			const sigma0l = u64.rotrSL(Ah, Al, 28) ^ u64.rotrBL(Ah, Al, 34) ^ u64.rotrBL(Ah, Al, 39);
			const MAJh = Ah & Bh ^ Ah & Ch ^ Bh & Ch;
			const MAJl = Al & Bl ^ Al & Cl ^ Bl & Cl;
			Hh = Gh | 0;
			Hl = Gl | 0;
			Gh = Fh | 0;
			Gl = Fl | 0;
			Fh = Eh | 0;
			Fl = El | 0;
			({h: Eh, l: El} = u64.add(Dh | 0, Dl | 0, T1h | 0, T1l | 0));
			Dh = Ch | 0;
			Dl = Cl | 0;
			Ch = Bh | 0;
			Cl = Bl | 0;
			Bh = Ah | 0;
			Bl = Al | 0;
			const All = u64.add3L(T1l, sigma0l, MAJl);
			Ah = u64.add3H(All, T1h, sigma0h, MAJh);
			Al = All | 0;
		}
		({h: Ah, l: Al} = u64.add(this.Ah | 0, this.Al | 0, Ah | 0, Al | 0));
		({h: Bh, l: Bl} = u64.add(this.Bh | 0, this.Bl | 0, Bh | 0, Bl | 0));
		({h: Ch, l: Cl} = u64.add(this.Ch | 0, this.Cl | 0, Ch | 0, Cl | 0));
		({h: Dh, l: Dl} = u64.add(this.Dh | 0, this.Dl | 0, Dh | 0, Dl | 0));
		({h: Eh, l: El} = u64.add(this.Eh | 0, this.El | 0, Eh | 0, El | 0));
		({h: Fh, l: Fl} = u64.add(this.Fh | 0, this.Fl | 0, Fh | 0, Fl | 0));
		({h: Gh, l: Gl} = u64.add(this.Gh | 0, this.Gl | 0, Gh | 0, Gl | 0));
		({h: Hh, l: Hl} = u64.add(this.Hh | 0, this.Hl | 0, Hh | 0, Hl | 0));
		this.set(Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl);
	}
	roundClean() {
		SHA512_W_H.fill(0);
		SHA512_W_L.fill(0);
	}
	destroy() {
		this.buffer.fill(0);
		this.set(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
	}
};
var sha512 = /* @__PURE__ */ wrapConstructor(() => new SHA512());
//#endregion
//#region node_modules/@noble/curves/esm/abstract/edwards.js
/*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
var _0n$1 = BigInt(0);
var _1n$2 = BigInt(1);
var _2n$2 = BigInt(2);
var _8n$1 = BigInt(8);
var VERIFY_DEFAULT = { zip215: true };
function validateOpts(curve) {
	const opts = validateBasic(curve);
	validateObject(curve, {
		hash: "function",
		a: "bigint",
		d: "bigint",
		randomBytes: "function"
	}, {
		adjustScalarBytes: "function",
		domain: "function",
		uvRatio: "function",
		mapToCurve: "function"
	});
	return Object.freeze({ ...opts });
}
/**
* Creates Twisted Edwards curve with EdDSA signatures.
* @example
* import { Field } from '@noble/curves/abstract/modular';
* // Before that, define BigInt-s: a, d, p, n, Gx, Gy, h
* const curve = twistedEdwards({ a, d, Fp: Field(p), n, Gx, Gy, h })
*/
function twistedEdwards(curveDef) {
	const CURVE = validateOpts(curveDef);
	const { Fp, n: CURVE_ORDER, prehash, hash: cHash, randomBytes, nByteLength, h: cofactor } = CURVE;
	const MASK = _2n$2 << BigInt(nByteLength * 8) - _1n$2;
	const modP = Fp.create;
	const Fn = Field(CURVE.n, CURVE.nBitLength);
	const uvRatio = CURVE.uvRatio || ((u, v) => {
		try {
			return {
				isValid: true,
				value: Fp.sqrt(u * Fp.inv(v))
			};
		} catch (e) {
			return {
				isValid: false,
				value: _0n$1
			};
		}
	});
	const adjustScalarBytes = CURVE.adjustScalarBytes || ((bytes) => bytes);
	const domain = CURVE.domain || ((data, ctx, phflag) => {
		abool("phflag", phflag);
		if (ctx.length || phflag) throw new Error("Contexts/pre-hash are not supported");
		return data;
	});
	function aCoordinate(title, n) {
		aInRange("coordinate " + title, n, _0n$1, MASK);
	}
	function assertPoint(other) {
		if (!(other instanceof Point)) throw new Error("ExtendedPoint expected");
	}
	const toAffineMemo = memoized((p, iz) => {
		const { ex: x, ey: y, ez: z } = p;
		const is0 = p.is0();
		if (iz == null) iz = is0 ? _8n$1 : Fp.inv(z);
		const ax = modP(x * iz);
		const ay = modP(y * iz);
		const zz = modP(z * iz);
		if (is0) return {
			x: _0n$1,
			y: _1n$2
		};
		if (zz !== _1n$2) throw new Error("invZ was invalid");
		return {
			x: ax,
			y: ay
		};
	});
	const assertValidMemo = memoized((p) => {
		const { a, d } = CURVE;
		if (p.is0()) throw new Error("bad point: ZERO");
		const { ex: X, ey: Y, ez: Z, et: T } = p;
		const X2 = modP(X * X);
		const Y2 = modP(Y * Y);
		const Z2 = modP(Z * Z);
		const Z4 = modP(Z2 * Z2);
		const aX2 = modP(X2 * a);
		if (modP(Z2 * modP(aX2 + Y2)) !== modP(Z4 + modP(d * modP(X2 * Y2)))) throw new Error("bad point: equation left != right (1)");
		if (modP(X * Y) !== modP(Z * T)) throw new Error("bad point: equation left != right (2)");
		return true;
	});
	class Point {
		constructor(ex, ey, ez, et) {
			this.ex = ex;
			this.ey = ey;
			this.ez = ez;
			this.et = et;
			aCoordinate("x", ex);
			aCoordinate("y", ey);
			aCoordinate("z", ez);
			aCoordinate("t", et);
			Object.freeze(this);
		}
		get x() {
			return this.toAffine().x;
		}
		get y() {
			return this.toAffine().y;
		}
		static fromAffine(p) {
			if (p instanceof Point) throw new Error("extended point not allowed");
			const { x, y } = p || {};
			aCoordinate("x", x);
			aCoordinate("y", y);
			return new Point(x, y, _1n$2, modP(x * y));
		}
		static normalizeZ(points) {
			const toInv = Fp.invertBatch(points.map((p) => p.ez));
			return points.map((p, i) => p.toAffine(toInv[i])).map(Point.fromAffine);
		}
		static msm(points, scalars) {
			return pippenger(Point, Fn, points, scalars);
		}
		_setWindowSize(windowSize) {
			wnaf.setWindowSize(this, windowSize);
		}
		assertValidity() {
			assertValidMemo(this);
		}
		equals(other) {
			assertPoint(other);
			const { ex: X1, ey: Y1, ez: Z1 } = this;
			const { ex: X2, ey: Y2, ez: Z2 } = other;
			const X1Z2 = modP(X1 * Z2);
			const X2Z1 = modP(X2 * Z1);
			const Y1Z2 = modP(Y1 * Z2);
			const Y2Z1 = modP(Y2 * Z1);
			return X1Z2 === X2Z1 && Y1Z2 === Y2Z1;
		}
		is0() {
			return this.equals(Point.ZERO);
		}
		negate() {
			return new Point(modP(-this.ex), this.ey, this.ez, modP(-this.et));
		}
		double() {
			const { a } = CURVE;
			const { ex: X1, ey: Y1, ez: Z1 } = this;
			const A = modP(X1 * X1);
			const B = modP(Y1 * Y1);
			const C = modP(_2n$2 * modP(Z1 * Z1));
			const D = modP(a * A);
			const x1y1 = X1 + Y1;
			const E = modP(modP(x1y1 * x1y1) - A - B);
			const G = D + B;
			const F = G - C;
			const H = D - B;
			const X3 = modP(E * F);
			const Y3 = modP(G * H);
			const T3 = modP(E * H);
			const Z3 = modP(F * G);
			return new Point(X3, Y3, Z3, T3);
		}
		add(other) {
			assertPoint(other);
			const { a, d } = CURVE;
			const { ex: X1, ey: Y1, ez: Z1, et: T1 } = this;
			const { ex: X2, ey: Y2, ez: Z2, et: T2 } = other;
			if (a === BigInt(-1)) {
				const A = modP((Y1 - X1) * (Y2 + X2));
				const B = modP((Y1 + X1) * (Y2 - X2));
				const F = modP(B - A);
				if (F === _0n$1) return this.double();
				const C = modP(Z1 * _2n$2 * T2);
				const D = modP(T1 * _2n$2 * Z2);
				const E = D + C;
				const G = B + A;
				const H = D - C;
				const X3 = modP(E * F);
				const Y3 = modP(G * H);
				const T3 = modP(E * H);
				const Z3 = modP(F * G);
				return new Point(X3, Y3, Z3, T3);
			}
			const A = modP(X1 * X2);
			const B = modP(Y1 * Y2);
			const C = modP(T1 * d * T2);
			const D = modP(Z1 * Z2);
			const E = modP((X1 + Y1) * (X2 + Y2) - A - B);
			const F = D - C;
			const G = D + C;
			const H = modP(B - a * A);
			const X3 = modP(E * F);
			const Y3 = modP(G * H);
			const T3 = modP(E * H);
			const Z3 = modP(F * G);
			return new Point(X3, Y3, Z3, T3);
		}
		subtract(other) {
			return this.add(other.negate());
		}
		wNAF(n) {
			return wnaf.wNAFCached(this, n, Point.normalizeZ);
		}
		multiply(scalar) {
			const n = scalar;
			aInRange("scalar", n, _1n$2, CURVE_ORDER);
			const { p, f } = this.wNAF(n);
			return Point.normalizeZ([p, f])[0];
		}
		multiplyUnsafe(scalar) {
			const n = scalar;
			aInRange("scalar", n, _0n$1, CURVE_ORDER);
			if (n === _0n$1) return I;
			if (this.equals(I) || n === _1n$2) return this;
			if (this.equals(G)) return this.wNAF(n).p;
			return wnaf.unsafeLadder(this, n);
		}
		isSmallOrder() {
			return this.multiplyUnsafe(cofactor).is0();
		}
		isTorsionFree() {
			return wnaf.unsafeLadder(this, CURVE_ORDER).is0();
		}
		toAffine(iz) {
			return toAffineMemo(this, iz);
		}
		clearCofactor() {
			const { h: cofactor } = CURVE;
			if (cofactor === _1n$2) return this;
			return this.multiplyUnsafe(cofactor);
		}
		static fromHex(hex, zip215 = false) {
			const { d, a } = CURVE;
			const len = Fp.BYTES;
			hex = ensureBytes("pointHex", hex, len);
			abool("zip215", zip215);
			const normed = hex.slice();
			const lastByte = hex[len - 1];
			normed[len - 1] = lastByte & -129;
			const y = bytesToNumberLE(normed);
			aInRange("pointHex.y", y, _0n$1, zip215 ? MASK : Fp.ORDER);
			const y2 = modP(y * y);
			const u = modP(y2 - _1n$2);
			const v = modP(d * y2 - a);
			let { isValid, value: x } = uvRatio(u, v);
			if (!isValid) throw new Error("Point.fromHex: invalid y coordinate");
			const isXOdd = (x & _1n$2) === _1n$2;
			const isLastByteOdd = (lastByte & 128) !== 0;
			if (!zip215 && x === _0n$1 && isLastByteOdd) throw new Error("Point.fromHex: x=0 and x_0=1");
			if (isLastByteOdd !== isXOdd) x = modP(-x);
			return Point.fromAffine({
				x,
				y
			});
		}
		static fromPrivateKey(privKey) {
			return getExtendedPublicKey(privKey).point;
		}
		toRawBytes() {
			const { x, y } = this.toAffine();
			const bytes = numberToBytesLE(y, Fp.BYTES);
			bytes[bytes.length - 1] |= x & _1n$2 ? 128 : 0;
			return bytes;
		}
		toHex() {
			return bytesToHex$1(this.toRawBytes());
		}
	}
	Point.BASE = new Point(CURVE.Gx, CURVE.Gy, _1n$2, modP(CURVE.Gx * CURVE.Gy));
	Point.ZERO = new Point(_0n$1, _1n$2, _1n$2, _0n$1);
	const { BASE: G, ZERO: I } = Point;
	const wnaf = wNAF(Point, nByteLength * 8);
	function modN(a) {
		return mod(a, CURVE_ORDER);
	}
	function modN_LE(hash) {
		return modN(bytesToNumberLE(hash));
	}
	/** Convenience method that creates public key and other stuff. RFC8032 5.1.5 */
	function getExtendedPublicKey(key) {
		const len = nByteLength;
		key = ensureBytes("private key", key, len);
		const hashed = ensureBytes("hashed private key", cHash(key), 2 * len);
		const head = adjustScalarBytes(hashed.slice(0, len));
		const prefix = hashed.slice(len, 2 * len);
		const scalar = modN_LE(head);
		const point = G.multiply(scalar);
		return {
			head,
			prefix,
			scalar,
			point,
			pointBytes: point.toRawBytes()
		};
	}
	function getPublicKey(privKey) {
		return getExtendedPublicKey(privKey).pointBytes;
	}
	function hashDomainToScalar(context = /* @__PURE__ */ new Uint8Array(), ...msgs) {
		const msg = concatBytes(...msgs);
		return modN_LE(cHash(domain(msg, ensureBytes("context", context), !!prehash)));
	}
	/** Signs message with privateKey. RFC8032 5.1.6 */
	function sign(msg, privKey, options = {}) {
		msg = ensureBytes("message", msg);
		if (prehash) msg = prehash(msg);
		const { prefix, scalar, pointBytes } = getExtendedPublicKey(privKey);
		const r = hashDomainToScalar(options.context, prefix, msg);
		const R = G.multiply(r).toRawBytes();
		const s = modN(r + hashDomainToScalar(options.context, R, pointBytes, msg) * scalar);
		aInRange("signature.s", s, _0n$1, CURVE_ORDER);
		return ensureBytes("result", concatBytes(R, numberToBytesLE(s, Fp.BYTES)), nByteLength * 2);
	}
	const verifyOpts = VERIFY_DEFAULT;
	function verify(sig, msg, publicKey, options = verifyOpts) {
		const { context, zip215 } = options;
		const len = Fp.BYTES;
		sig = ensureBytes("signature", sig, 2 * len);
		msg = ensureBytes("message", msg);
		if (zip215 !== void 0) abool("zip215", zip215);
		if (prehash) msg = prehash(msg);
		const s = bytesToNumberLE(sig.slice(len, 2 * len));
		let A, R, SB;
		try {
			A = Point.fromHex(publicKey, zip215);
			R = Point.fromHex(sig.slice(0, len), zip215);
			SB = G.multiplyUnsafe(s);
		} catch (error) {
			return false;
		}
		if (!zip215 && A.isSmallOrder()) return false;
		const k = hashDomainToScalar(context, R.toRawBytes(), A.toRawBytes(), msg);
		return R.add(A.multiplyUnsafe(k)).subtract(SB).clearCofactor().equals(Point.ZERO);
	}
	G._setWindowSize(8);
	return {
		CURVE,
		getPublicKey,
		sign,
		verify,
		ExtendedPoint: Point,
		utils: {
			getExtendedPublicKey,
			randomPrivateKey: () => randomBytes(Fp.BYTES),
			/**
			* We're doing scalar multiplication (used in getPublicKey etc) with precomputed BASE_POINT
			* values. This slows down first getPublicKey() by milliseconds (see Speed section),
			* but allows to speed-up subsequent getPublicKey() calls up to 20x.
			* @param windowSize 2, 4, 8, 16
			*/
			precompute(windowSize = 8, point = Point.BASE) {
				point._setWindowSize(windowSize);
				point.multiply(BigInt(3));
				return point;
			}
		}
	};
}
//#endregion
//#region node_modules/@noble/curves/esm/ed25519.js
/*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
/**
* ed25519 Twisted Edwards curve with following addons:
* - X25519 ECDH
* - Ristretto cofactor elimination
* - Elligator hash-to-group / point indistinguishability
*/
var ED25519_P = BigInt("57896044618658097711785492504343953926634992332820282019728792003956564819949");
var ED25519_SQRT_M1 = /* @__PURE__ */ BigInt("19681161376707505956807079304988542015446066515923890162744021073123829784752");
var _1n$1 = BigInt(1);
var _2n$1 = BigInt(2);
var _5n = BigInt(5);
var _8n = BigInt(8);
function ed25519_pow_2_252_3(x) {
	const _10n = BigInt(10), _20n = BigInt(20), _40n = BigInt(40), _80n = BigInt(80);
	const P = ED25519_P;
	const b2 = x * x % P * x % P;
	const b5 = pow2(pow2(b2, _2n$1, P) * b2 % P, _1n$1, P) * x % P;
	const b10 = pow2(b5, _5n, P) * b5 % P;
	const b20 = pow2(b10, _10n, P) * b10 % P;
	const b40 = pow2(b20, _20n, P) * b20 % P;
	const b80 = pow2(b40, _40n, P) * b40 % P;
	return {
		pow_p_5_8: pow2(pow2(pow2(pow2(b80, _80n, P) * b80 % P, _80n, P) * b80 % P, _10n, P) * b10 % P, _2n$1, P) * x % P,
		b2
	};
}
function adjustScalarBytes(bytes) {
	bytes[0] &= 248;
	bytes[31] &= 127;
	bytes[31] |= 64;
	return bytes;
}
function uvRatio(u, v) {
	const P = ED25519_P;
	const v3 = mod(v * v * v, P);
	const pow = ed25519_pow_2_252_3(u * mod(v3 * v3 * v, P)).pow_p_5_8;
	let x = mod(u * v3 * pow, P);
	const vx2 = mod(v * x * x, P);
	const root1 = x;
	const root2 = mod(x * ED25519_SQRT_M1, P);
	const useRoot1 = vx2 === u;
	const useRoot2 = vx2 === mod(-u, P);
	const noRoot = vx2 === mod(-u * ED25519_SQRT_M1, P);
	if (useRoot1) x = root1;
	if (useRoot2 || noRoot) x = root2;
	if (isNegativeLE(x, P)) x = mod(-x, P);
	return {
		isValid: useRoot1 || useRoot2,
		value: x
	};
}
var Fp = /* @__PURE__ */ (() => Field(ED25519_P, void 0, true))();
var ed25519Defaults = /* @__PURE__ */ (() => ({
	a: BigInt(-1),
	d: BigInt("37095705934669439343138083508754565189542113879843219016388785533085940283555"),
	Fp,
	n: BigInt("7237005577332262213973186563042994240857116359379907606001950938285454250989"),
	h: _8n,
	Gx: BigInt("15112221349535400772501151409588531511454012693041857206046113283949847762202"),
	Gy: BigInt("46316835694926478169428394003475163141307993866256225615783033603165251855960"),
	hash: sha512,
	randomBytes,
	adjustScalarBytes,
	uvRatio
}))();
/**
* ed25519 curve with EdDSA signatures.
*/
var ed25519 = /* @__PURE__ */ (() => twistedEdwards(ed25519Defaults))();
//#endregion
//#region node_modules/@noble/hashes/esm/ripemd160.js
var Rho = /* @__PURE__ */ new Uint8Array([
	7,
	4,
	13,
	1,
	10,
	6,
	15,
	3,
	12,
	0,
	9,
	5,
	2,
	14,
	11,
	8
]);
var Id = /* @__PURE__ */ new Uint8Array(new Array(16).fill(0).map((_, i) => i));
var Pi = /* @__PURE__ */ Id.map((i) => (9 * i + 5) % 16);
var idxL = [Id];
var idxR = [Pi];
for (let i = 0; i < 4; i++) for (let j of [idxL, idxR]) j.push(j[i].map((k) => Rho[k]));
var shifts = /* @__PURE__ */ [
	[
		11,
		14,
		15,
		12,
		5,
		8,
		7,
		9,
		11,
		13,
		14,
		15,
		6,
		7,
		9,
		8
	],
	[
		12,
		13,
		11,
		15,
		6,
		9,
		9,
		7,
		12,
		15,
		11,
		13,
		7,
		8,
		7,
		7
	],
	[
		13,
		15,
		14,
		11,
		7,
		7,
		6,
		8,
		13,
		14,
		13,
		12,
		5,
		5,
		6,
		9
	],
	[
		14,
		11,
		12,
		14,
		8,
		6,
		5,
		5,
		15,
		12,
		15,
		14,
		9,
		9,
		8,
		6
	],
	[
		15,
		12,
		13,
		13,
		9,
		5,
		8,
		6,
		14,
		11,
		12,
		11,
		8,
		6,
		5,
		5
	]
].map((i) => new Uint8Array(i));
var shiftsL = /* @__PURE__ */ idxL.map((idx, i) => idx.map((j) => shifts[i][j]));
var shiftsR = /* @__PURE__ */ idxR.map((idx, i) => idx.map((j) => shifts[i][j]));
var Kl = /* @__PURE__ */ new Uint32Array([
	0,
	1518500249,
	1859775393,
	2400959708,
	2840853838
]);
var Kr = /* @__PURE__ */ new Uint32Array([
	1352829926,
	1548603684,
	1836072691,
	2053994217,
	0
]);
function f(group, x, y, z) {
	if (group === 0) return x ^ y ^ z;
	else if (group === 1) return x & y | ~x & z;
	else if (group === 2) return (x | ~y) ^ z;
	else if (group === 3) return x & z | y & ~z;
	else return x ^ (y | ~z);
}
var R_BUF = /* @__PURE__ */ new Uint32Array(16);
var RIPEMD160 = class extends HashMD {
	constructor() {
		super(64, 20, 8, true);
		this.h0 = 1732584193;
		this.h1 = -271733879;
		this.h2 = -1732584194;
		this.h3 = 271733878;
		this.h4 = -1009589776;
	}
	get() {
		const { h0, h1, h2, h3, h4 } = this;
		return [
			h0,
			h1,
			h2,
			h3,
			h4
		];
	}
	set(h0, h1, h2, h3, h4) {
		this.h0 = h0 | 0;
		this.h1 = h1 | 0;
		this.h2 = h2 | 0;
		this.h3 = h3 | 0;
		this.h4 = h4 | 0;
	}
	process(view, offset) {
		for (let i = 0; i < 16; i++, offset += 4) R_BUF[i] = view.getUint32(offset, true);
		let al = this.h0 | 0, ar = al, bl = this.h1 | 0, br = bl, cl = this.h2 | 0, cr = cl, dl = this.h3 | 0, dr = dl, el = this.h4 | 0, er = el;
		for (let group = 0; group < 5; group++) {
			const rGroup = 4 - group;
			const hbl = Kl[group], hbr = Kr[group];
			const rl = idxL[group], rr = idxR[group];
			const sl = shiftsL[group], sr = shiftsR[group];
			for (let i = 0; i < 16; i++) {
				const tl = rotl(al + f(group, bl, cl, dl) + R_BUF[rl[i]] + hbl, sl[i]) + el | 0;
				al = el, el = dl, dl = rotl(cl, 10) | 0, cl = bl, bl = tl;
			}
			for (let i = 0; i < 16; i++) {
				const tr = rotl(ar + f(rGroup, br, cr, dr) + R_BUF[rr[i]] + hbr, sr[i]) + er | 0;
				ar = er, er = dr, dr = rotl(cr, 10) | 0, cr = br, br = tr;
			}
		}
		this.set(this.h1 + cl + dr | 0, this.h2 + dl + er | 0, this.h3 + el + ar | 0, this.h4 + al + br | 0, this.h0 + bl + cr | 0);
	}
	roundClean() {
		R_BUF.fill(0);
	}
	destroy() {
		this.destroyed = true;
		this.buffer.fill(0);
		this.set(0, 0, 0, 0, 0);
	}
};
/**
* RIPEMD-160 - a hash function from 1990s.
* @param message - msg that would be hashed
*/
var ripemd160 = /* @__PURE__ */ wrapConstructor(() => new RIPEMD160());
//#endregion
//#region node_modules/@noble/hashes/esm/sha3.js
var SHA3_PI = [];
var SHA3_ROTL = [];
var _SHA3_IOTA = [];
var _0n = /* @__PURE__ */ BigInt(0);
var _1n = /* @__PURE__ */ BigInt(1);
var _2n = /* @__PURE__ */ BigInt(2);
var _7n = /* @__PURE__ */ BigInt(7);
var _256n = /* @__PURE__ */ BigInt(256);
var _0x71n = /* @__PURE__ */ BigInt(113);
for (let round = 0, R = _1n, x = 1, y = 0; round < 24; round++) {
	[x, y] = [y, (2 * x + 3 * y) % 5];
	SHA3_PI.push(2 * (5 * y + x));
	SHA3_ROTL.push((round + 1) * (round + 2) / 2 % 64);
	let t = _0n;
	for (let j = 0; j < 7; j++) {
		R = (R << _1n ^ (R >> _7n) * _0x71n) % _256n;
		if (R & _2n) t ^= _1n << (_1n << /* @__PURE__ */ BigInt(j)) - _1n;
	}
	_SHA3_IOTA.push(t);
}
var [SHA3_IOTA_H, SHA3_IOTA_L] = /* @__PURE__ */ split(_SHA3_IOTA, true);
var rotlH = (h, l, s) => s > 32 ? rotlBH(h, l, s) : rotlSH(h, l, s);
var rotlL = (h, l, s) => s > 32 ? rotlBL(h, l, s) : rotlSL(h, l, s);
function keccakP(s, rounds = 24) {
	const B = /* @__PURE__ */ new Uint32Array(10);
	for (let round = 24 - rounds; round < 24; round++) {
		for (let x = 0; x < 10; x++) B[x] = s[x] ^ s[x + 10] ^ s[x + 20] ^ s[x + 30] ^ s[x + 40];
		for (let x = 0; x < 10; x += 2) {
			const idx1 = (x + 8) % 10;
			const idx0 = (x + 2) % 10;
			const B0 = B[idx0];
			const B1 = B[idx0 + 1];
			const Th = rotlH(B0, B1, 1) ^ B[idx1];
			const Tl = rotlL(B0, B1, 1) ^ B[idx1 + 1];
			for (let y = 0; y < 50; y += 10) {
				s[x + y] ^= Th;
				s[x + y + 1] ^= Tl;
			}
		}
		let curH = s[2];
		let curL = s[3];
		for (let t = 0; t < 24; t++) {
			const shift = SHA3_ROTL[t];
			const Th = rotlH(curH, curL, shift);
			const Tl = rotlL(curH, curL, shift);
			const PI = SHA3_PI[t];
			curH = s[PI];
			curL = s[PI + 1];
			s[PI] = Th;
			s[PI + 1] = Tl;
		}
		for (let y = 0; y < 50; y += 10) {
			for (let x = 0; x < 10; x++) B[x] = s[y + x];
			for (let x = 0; x < 10; x++) s[y + x] ^= ~B[(x + 2) % 10] & B[(x + 4) % 10];
		}
		s[0] ^= SHA3_IOTA_H[round];
		s[1] ^= SHA3_IOTA_L[round];
	}
	B.fill(0);
}
var Keccak = class Keccak extends Hash {
	constructor(blockLen, suffix, outputLen, enableXOF = false, rounds = 24) {
		super();
		this.blockLen = blockLen;
		this.suffix = suffix;
		this.outputLen = outputLen;
		this.enableXOF = enableXOF;
		this.rounds = rounds;
		this.pos = 0;
		this.posOut = 0;
		this.finished = false;
		this.destroyed = false;
		number(outputLen);
		if (0 >= this.blockLen || this.blockLen >= 200) throw new Error("Sha3 supports only keccak-f1600 function");
		this.state = /* @__PURE__ */ new Uint8Array(200);
		this.state32 = u32(this.state);
	}
	keccak() {
		if (!isLE) byteSwap32(this.state32);
		keccakP(this.state32, this.rounds);
		if (!isLE) byteSwap32(this.state32);
		this.posOut = 0;
		this.pos = 0;
	}
	update(data) {
		exists(this);
		const { blockLen, state } = this;
		data = toBytes(data);
		const len = data.length;
		for (let pos = 0; pos < len;) {
			const take = Math.min(blockLen - this.pos, len - pos);
			for (let i = 0; i < take; i++) state[this.pos++] ^= data[pos++];
			if (this.pos === blockLen) this.keccak();
		}
		return this;
	}
	finish() {
		if (this.finished) return;
		this.finished = true;
		const { state, suffix, pos, blockLen } = this;
		state[pos] ^= suffix;
		if ((suffix & 128) !== 0 && pos === blockLen - 1) this.keccak();
		state[blockLen - 1] ^= 128;
		this.keccak();
	}
	writeInto(out) {
		exists(this, false);
		bytes(out);
		this.finish();
		const bufferOut = this.state;
		const { blockLen } = this;
		for (let pos = 0, len = out.length; pos < len;) {
			if (this.posOut >= blockLen) this.keccak();
			const take = Math.min(blockLen - this.posOut, len - pos);
			out.set(bufferOut.subarray(this.posOut, this.posOut + take), pos);
			this.posOut += take;
			pos += take;
		}
		return out;
	}
	xofInto(out) {
		if (!this.enableXOF) throw new Error("XOF is not possible for this instance");
		return this.writeInto(out);
	}
	xof(bytes) {
		number(bytes);
		return this.xofInto(new Uint8Array(bytes));
	}
	digestInto(out) {
		output(out, this);
		if (this.finished) throw new Error("digest() was already called");
		this.writeInto(out);
		this.destroy();
		return out;
	}
	digest() {
		return this.digestInto(new Uint8Array(this.outputLen));
	}
	destroy() {
		this.destroyed = true;
		this.state.fill(0);
	}
	_cloneInto(to) {
		const { blockLen, suffix, outputLen, rounds, enableXOF } = this;
		to || (to = new Keccak(blockLen, suffix, outputLen, enableXOF, rounds));
		to.state32.set(this.state32);
		to.pos = this.pos;
		to.posOut = this.posOut;
		to.finished = this.finished;
		to.rounds = rounds;
		to.suffix = suffix;
		to.outputLen = outputLen;
		to.enableXOF = enableXOF;
		to.destroyed = this.destroyed;
		return to;
	}
};
var gen = (suffix, blockLen, outputLen) => wrapConstructor(() => new Keccak(blockLen, suffix, outputLen));
/**
* keccak-256 hash function. Different from SHA3-256.
* @param message - that would be hashed
*/
var keccak_256 = /* @__PURE__ */ gen(1, 136, 256 / 8);
//#endregion
//#region src/shared/signers.ts
var import_dist = require_dist();
var DERIVE_PATHS = {
	BTC: "ego:bitcoin:0",
	ETH: "ego:ethereum:0",
	BNB: "ego:bnb:0",
	POL: "ego:ethereum:0",
	SOL: "ego:solana:0",
	DOGE: "ego:dogecoin:0",
	LTC: "ego:litecoin:0",
	XRP: "ego:xrp:0"
};
var SIGNABLE = /* @__PURE__ */ new Set([
	"BTC",
	"ETH",
	"BNB"
]);
function isSignableChain(chain) {
	return SIGNABLE.has(chain) && chain !== "POL";
}
function derivePrivkey(seed, chain) {
	return hmac(sha512, seed, new TextEncoder().encode(DERIVE_PATHS[chain])).slice(0, 32);
}
var B58_STD = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
var B58_XRP = "rpshnaf39wBUDNEGHJKLM4PQRST7VWXYZ2bcdeCg65jkm8oFqi1tuvAxyz";
function base58(bytes, alphabet = B58_STD) {
	let n = 0n;
	for (const b of bytes) n = n * 256n + BigInt(b);
	let out = "";
	while (n > 0n) {
		out = alphabet[Number(n % 58n)] + out;
		n /= 58n;
	}
	for (const b of bytes) if (b === 0) out = alphabet[0] + out;
	else break;
	return out;
}
function base58check(version, payload, alphabet = B58_STD) {
	const data = concat(new Uint8Array([version]), payload);
	return base58(concat(data, sha256(sha256(data)).slice(0, 4)), alphabet);
}
function hash160(data) {
	return ripemd160(sha256(data));
}
function sha256d(data) {
	return sha256(sha256(data));
}
function bytesToHex(b) {
	return Array.from(b).map((x) => x.toString(16).padStart(2, "0")).join("");
}
function hexToBytes(hex) {
	const h = hex.replace(/^0x/, "");
	const out = new Uint8Array(h.length / 2);
	for (let i = 0; i < out.length; i++) out[i] = parseInt(h.slice(i * 2, i * 2 + 2), 16);
	return out;
}
function concat(...arrs) {
	const len = arrs.reduce((s, a) => s + a.length, 0);
	const out = new Uint8Array(len);
	let off = 0;
	for (const a of arrs) {
		out.set(a, off);
		off += a.length;
	}
	return out;
}
function parseUnits(amount, decimals) {
	const s = amount.trim();
	if (!/^\d+(\.\d+)?$/.test(s)) throw new Error("Invalid amount");
	const [whole, frac = ""] = s.split(".");
	if (frac.length > decimals) throw new Error(`Too many decimal places (max ${decimals})`);
	return BigInt(whole) * 10n ** BigInt(decimals) + BigInt(frac.padEnd(decimals, "0") || "0");
}
function eip55(addr20) {
	const hexLower = bytesToHex(addr20);
	const hash = bytesToHex(keccak_256(new TextEncoder().encode(hexLower)));
	let out = "0x";
	for (let i = 0; i < hexLower.length; i++) {
		const c = hexLower[i];
		out += /[a-f]/.test(c) && parseInt(hash[i], 16) >= 8 ? c.toUpperCase() : c;
	}
	return out;
}
function deriveAddress(seed, chain) {
	const priv = derivePrivkey(seed, chain);
	switch (chain) {
		case "BTC":
		case "LTC": {
			const pub = secp256k1.getPublicKey(priv, true);
			const words = import_dist.bech32.toWords(hash160(pub));
			return import_dist.bech32.encode(chain === "BTC" ? "bc" : "ltc", [0, ...words]);
		}
		case "ETH":
		case "BNB":
		case "POL": return eip55(keccak_256(secp256k1.getPublicKey(priv, false).slice(1)).slice(12));
		case "DOGE": return base58check(30, hash160(secp256k1.getPublicKey(priv, true)));
		case "SOL": return base58(ed25519.getPublicKey(priv));
		case "XRP": return base58check(0, hash160(secp256k1.getPublicKey(priv, true)), B58_XRP);
	}
}
var EVM = {
	ETH: {
		rpc: "https://eth.llamarpc.com",
		chainId: 1n,
		explorer: "https://etherscan.io/tx/"
	},
	BNB: {
		rpc: "https://bsc-dataseed.binance.org",
		chainId: 56n,
		explorer: "https://bscscan.com/tx/"
	}
};
async function evmRpc(rpc, method, params) {
	const j = await (await fetch(rpc, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			jsonrpc: "2.0",
			id: 1,
			method,
			params
		})
	})).json();
	if (j.error) throw new Error(j.error.message ?? "RPC error");
	return j.result;
}
function bigintToMinimal(n) {
	if (n === 0n) return /* @__PURE__ */ new Uint8Array(0);
	let hex = n.toString(16);
	if (hex.length % 2) hex = "0" + hex;
	return hexToBytes(hex);
}
function rlpEncode(item) {
	if (item instanceof Uint8Array) {
		if (item.length === 1 && item[0] < 128) return item;
		return concat(rlpLength(item.length, 128), item);
	}
	const body = concat(...item.map(rlpEncode));
	return concat(rlpLength(body.length, 192), body);
}
function rlpLength(len, offset) {
	if (len < 56) return new Uint8Array([offset + len]);
	const lenBytes = bigintToMinimal(BigInt(len));
	return concat(new Uint8Array([offset + 55 + lenBytes.length]), lenBytes);
}
async function sendEvm(seed, chain, to, amount, token) {
	if (!/^0x[0-9a-fA-F]{40}$/.test(to)) throw new Error("Invalid recipient address");
	const cfg = EVM[chain];
	const priv = derivePrivkey(seed, chain);
	const from = deriveAddress(seed, chain);
	let txTo;
	let value;
	let data;
	if (token) {
		const units = parseUnits(amount, token.decimals);
		txTo = token.contract;
		value = 0n;
		data = hexToBytes("a9059cbb" + to.replace(/^0x/, "").toLowerCase().padStart(64, "0") + units.toString(16).padStart(64, "0"));
	} else {
		txTo = to;
		value = parseUnits(amount, 18);
		data = /* @__PURE__ */ new Uint8Array(0);
	}
	const [nonceHex, gasPriceHex] = await Promise.all([evmRpc(cfg.rpc, "eth_getTransactionCount", [from, "pending"]), evmRpc(cfg.rpc, "eth_gasPrice", [])]);
	const nonce = BigInt(nonceHex);
	const gasPrice = BigInt(gasPriceHex) * 110n / 100n;
	let gasLimit = 21000n;
	if (token) try {
		const est = await evmRpc(cfg.rpc, "eth_estimateGas", [{
			from,
			to: txTo,
			data: "0x" + bytesToHex(data)
		}]);
		gasLimit = BigInt(est) * 120n / 100n;
	} catch {
		gasLimit = 100000n;
	}
	const toBytes = hexToBytes(txTo);
	const fields = [
		bigintToMinimal(nonce),
		bigintToMinimal(gasPrice),
		bigintToMinimal(gasLimit),
		toBytes,
		bigintToMinimal(value),
		data
	];
	const sigHash = keccak_256(rlpEncode([
		...fields,
		bigintToMinimal(cfg.chainId),
		/* @__PURE__ */ new Uint8Array(0),
		/* @__PURE__ */ new Uint8Array(0)
	]));
	const sig = secp256k1.sign(sigHash, priv);
	const v = cfg.chainId * 2n + 35n + BigInt(sig.recovery);
	const raw = rlpEncode([
		...fields,
		bigintToMinimal(v),
		bigintToMinimal(sig.r),
		bigintToMinimal(sig.s)
	]);
	const txid = await evmRpc(cfg.rpc, "eth_sendRawTransaction", ["0x" + bytesToHex(raw)]);
	return {
		txid,
		explorer_url: cfg.explorer + txid
	};
}
var BTC_API = "https://blockstream.info/api";
var DUST_SATS = 546n;
function varint(n) {
	if (n < 253) return new Uint8Array([n]);
	if (n <= 65535) return new Uint8Array([
		253,
		n & 255,
		n >> 8
	]);
	throw new Error("Too many items");
}
function u32le(n) {
	const b = /* @__PURE__ */ new Uint8Array(4);
	new DataView(b.buffer).setUint32(0, n, true);
	return b;
}
function u64le(n) {
	const b = /* @__PURE__ */ new Uint8Array(8);
	new DataView(b.buffer).setBigUint64(0, n, true);
	return b;
}
function txidLe(txid) {
	return hexToBytes(txid).reverse();
}
var B58_ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
function base58Decode(s) {
	let n = 0n;
	for (const c of s) {
		const i = B58_ALPHABET.indexOf(c);
		if (i < 0) throw new Error("Invalid base58 character");
		n = n * 58n + BigInt(i);
	}
	let hex = n.toString(16);
	if (hex.length % 2) hex = "0" + hex;
	let bytes = hexToBytes(hex);
	let zeros = 0;
	for (const c of s) if (c === "1") zeros++;
	else break;
	if (zeros) bytes = concat(new Uint8Array(zeros), bytes);
	return bytes;
}
function btcOutputScript(address) {
	const addr = address.trim();
	if (addr.toLowerCase().startsWith("bc1")) {
		const lower = addr.toLowerCase();
		let decoded;
		try {
			decoded = lower.startsWith("bc1p") ? import_dist.bech32m.decode(lower) : import_dist.bech32.decode(lower);
		} catch {
			throw new Error("Invalid bech32 address");
		}
		const version = decoded.words[0];
		const program = new Uint8Array(import_dist.bech32.fromWords(decoded.words.slice(1)));
		if (version === 0 && program.length !== 20 && program.length !== 32) throw new Error("Invalid witness program");
		const opVersion = version === 0 ? 0 : 80 + version;
		return concat(new Uint8Array([opVersion, program.length]), program);
	}
	const payload = base58Decode(addr);
	if (payload.length !== 25) throw new Error("Invalid address");
	if (bytesToHex(sha256d(payload.slice(0, 21)).slice(0, 4)) !== bytesToHex(payload.slice(21))) throw new Error("Bad address checksum");
	const version = payload[0];
	const h = payload.slice(1, 21);
	if (version === 0) return concat(hexToBytes("76a914"), h, hexToBytes("88ac"));
	if (version === 5) return concat(hexToBytes("a914"), h, hexToBytes("87"));
	throw new Error("Unsupported address version");
}
function serializeOutput(value, script) {
	return concat(u64le(value), varint(script.length), script);
}
async function sendBtc(seed, to, amount) {
	const priv = derivePrivkey(seed, "BTC");
	const pub = secp256k1.getPublicKey(priv, true);
	const myH160 = hash160(pub);
	const myAddress = deriveAddress(seed, "BTC");
	const amountSats = parseUnits(amount, 8);
	if (amountSats < DUST_SATS) throw new Error("Amount below dust limit (0.00000546 BTC)");
	const toScript = btcOutputScript(to);
	const utxoRes = await fetch(`${BTC_API}/address/${myAddress}/utxo`);
	if (!utxoRes.ok) throw new Error(`UTXO fetch failed: HTTP ${utxoRes.status}`);
	const utxos = await utxoRes.json();
	if (!utxos.length) throw new Error("No spendable balance");
	utxos.sort((a, b) => b.value - a.value);
	let feeRate = 5;
	try {
		const fees = await (await fetch(`${BTC_API}/fee-estimates`)).json();
		feeRate = Math.max(1, Math.ceil(fees["3"] ?? fees["6"] ?? 5));
	} catch {}
	const selected = [];
	let inputSats = 0n;
	let fee = 0n;
	for (const u of utxos) {
		selected.push(u);
		inputSats += BigInt(u.value);
		const vsize = 11 + 68 * selected.length + 62;
		fee = BigInt(vsize * feeRate);
		if (inputSats >= amountSats + fee) break;
	}
	if (inputSats < amountSats + fee) throw new Error("Insufficient balance (including network fee)");
	const change = inputSats - amountSats - fee;
	const myScript = concat(new Uint8Array([0, 20]), myH160);
	const outputs = [serializeOutput(amountSats, toScript)];
	if (change > DUST_SATS) outputs.push(serializeOutput(change, myScript));
	const version = u32le(2);
	const locktime = u32le(0);
	const sequence = u32le(4294967293);
	const hashPrevouts = sha256d(concat(...selected.map((u) => concat(txidLe(u.txid), u32le(u.vout)))));
	const hashSequence = sha256d(concat(...selected.map(() => sequence)));
	const outputsBlob = concat(...outputs);
	const hashOutputs = sha256d(outputsBlob);
	const scriptCode = concat(hexToBytes("1976a914"), myH160, hexToBytes("88ac"));
	const witnesses = [];
	for (const u of selected) {
		const sigHash = sha256d(concat(version, hashPrevouts, hashSequence, txidLe(u.txid), u32le(u.vout), scriptCode, u64le(BigInt(u.value)), sequence, hashOutputs, locktime, u32le(1)));
		const der = concat(secp256k1.sign(sigHash, priv, { lowS: true }).toDERRawBytes(), new Uint8Array([1]));
		witnesses.push(concat(varint(2), varint(der.length), der, varint(pub.length), pub));
	}
	const vin = concat(varint(selected.length), ...selected.map((u) => concat(txidLe(u.txid), u32le(u.vout), varint(0), sequence)));
	const vout = concat(varint(outputs.length), outputsBlob);
	const rawTx = concat(version, new Uint8Array([0, 1]), vin, vout, ...witnesses, locktime);
	const broadcast = await fetch(`${BTC_API}/tx`, {
		method: "POST",
		body: bytesToHex(rawTx)
	});
	const text = await broadcast.text();
	if (!broadcast.ok) throw new Error(`Broadcast rejected: ${text.slice(0, 140)}`);
	return {
		txid: text.trim(),
		explorer_url: `https://blockstream.info/tx/${text.trim()}`
	};
}
//#endregion
//#region src/background/index.ts
var unlockedSeed = null;
var pendingConnections = /* @__PURE__ */ new Map();
async function loadWalletData() {
	return new Promise((resolve) => {
		chrome.storage.local.get(["walletData"], (result) => {
			resolve(result.walletData ?? null);
		});
	});
}
async function saveWalletData(data) {
	return new Promise((resolve) => {
		chrome.storage.local.set({ walletData: data }, resolve);
	});
}
function getRpcUrl(network) {
	if (!network) return DEFAULT_RPC_URL;
	return NETWORKS[network]?.rpcUrl ?? "http://127.0.0.1:47395";
}
async function generateWallet(password) {
	const seed = generateSeed();
	const { publicKey } = seedToKeypair(seed);
	const address = publicKeyToAddress(publicKey);
	const mnemonic = await seedToMnemonic(seed);
	await saveWalletData({
		encryptedSeed: await encryptSeed(seed, password),
		address,
		publicKeyHex: Array.from(publicKey).map((b) => b.toString(16).padStart(2, "0")).join(""),
		locked: false,
		approvedOrigins: [],
		network: "testnet"
	});
	unlockedSeed = seed;
	return {
		success: true,
		data: {
			address,
			mnemonic
		}
	};
}
async function importWallet(input, password) {
	const words = input.trim().split(/\s+/);
	let seed = null;
	if (words.length === 24) {
		seed = mnemonicToSeed(words);
		if (!seed) return {
			success: false,
			error: "Invalid recovery phrase — check every word (and their order)"
		};
	} else {
		seed = hexToSeed(input);
		if (!seed) return {
			success: false,
			error: "Provide your 24-word recovery phrase, or the 64-character hex seed (with or without 0x)"
		};
	}
	const { publicKey } = seedToKeypair(seed);
	const address = publicKeyToAddress(publicKey);
	await saveWalletData({
		encryptedSeed: await encryptSeed(seed, password),
		address,
		publicKeyHex: Array.from(publicKey).map((b) => b.toString(16).padStart(2, "0")).join(""),
		locked: false,
		approvedOrigins: [],
		network: "testnet"
	});
	unlockedSeed = seed;
	return {
		success: true,
		data: { address }
	};
}
async function unlockWallet(password) {
	const walletData = await loadWalletData();
	if (!walletData) return {
		success: false,
		error: "No wallet found"
	};
	const seed = await decryptSeed(walletData.encryptedSeed, password);
	if (!seed) return {
		success: false,
		error: "Wrong password"
	};
	unlockedSeed = seed;
	walletData.locked = false;
	await saveWalletData(walletData);
	return {
		success: true,
		data: { address: walletData.address }
	};
}
async function lockWallet() {
	unlockedSeed = null;
	const walletData = await loadWalletData();
	if (walletData) {
		walletData.locked = true;
		await saveWalletData(walletData);
	}
	return { success: true };
}
async function getWalletState() {
	const walletData = await loadWalletData();
	const pending = [...pendingConnections.values()][0];
	if (!walletData) return {
		success: true,
		data: {
			hasWallet: false,
			locked: true
		}
	};
	return {
		success: true,
		data: {
			hasWallet: true,
			locked: !unlockedSeed,
			address: walletData.address,
			publicKeyHex: walletData.publicKeyHex,
			network: walletData.network,
			pendingConnection: pending?.info
		}
	};
}
async function getMnemonic(password) {
	const walletData = await loadWalletData();
	if (!walletData) return {
		success: false,
		error: "No wallet found"
	};
	const seed = await decryptSeed(walletData.encryptedSeed, password);
	if (!seed) return {
		success: false,
		error: "Wrong password"
	};
	return {
		success: true,
		data: { mnemonic: await seedToMnemonic(seed) }
	};
}
async function sendTransaction(params) {
	if (!unlockedSeed) return {
		success: false,
		error: "Wallet is locked"
	};
	const walletData = await loadWalletData();
	if (!walletData) return {
		success: false,
		error: "No wallet"
	};
	try {
		const rpcUrl = getRpcUrl(walletData.network);
		const info = await getNonceInfo(walletData.address, rpcUrl);
		const tx = buildSignedEgoTx(unlockedSeed, walletData.address, params.to, Math.round(params.amount_egoc * 1e6), info.next, info.fee_uegoc, params.memo ?? "");
		return {
			success: true,
			data: { tx_hash: (await submitTx(tx, rpcUrl)).tx_hash ?? tx.hash }
		};
	} catch (e) {
		return {
			success: false,
			error: e.message
		};
	}
}
async function getWalletBalance() {
	const walletData = await loadWalletData();
	if (!walletData) return {
		success: false,
		error: "No wallet"
	};
	try {
		const rpcUrl = getRpcUrl(walletData.network);
		const result = await getBalance(walletData.address, rpcUrl);
		return {
			success: true,
			data: {
				balance_egoc: result.balance_egoc,
				balance_uegoc: result.balance_uegoc
			}
		};
	} catch (e) {
		return {
			success: false,
			error: e.message
		};
	}
}
async function handleSignMessage(messageHex) {
	if (!unlockedSeed) return {
		success: false,
		error: "Wallet is locked"
	};
	return {
		success: true,
		data: { signature: signMessage(Uint8Array.from(messageHex.replace(/^0x/, "").match(/.{1,2}/g).map((b) => parseInt(b, 16))), unlockedSeed) }
	};
}
async function handleConnectDapp(info) {
	if (!await loadWalletData()) return {
		success: false,
		error: "No wallet"
	};
	if (!unlockedSeed) return {
		success: false,
		error: "Wallet is locked"
	};
	return new Promise((resolve) => {
		pendingConnections.set(info.requestId, {
			resolve: (approved) => {
				pendingConnections.delete(info.requestId);
				resolve({
					success: true,
					data: { approved }
				});
			},
			info
		});
		chrome.action.openPopup?.();
	});
}
async function approveConnection(requestId) {
	const walletData = await loadWalletData();
	const pending = pendingConnections.get(requestId);
	if (!pending) return {
		success: false,
		error: "No pending connection"
	};
	if (walletData && !walletData.approvedOrigins.includes(pending.info.origin)) {
		walletData.approvedOrigins.push(pending.info.origin);
		await saveWalletData(walletData);
	}
	pending.resolve(true);
	return { success: true };
}
async function rejectConnection(requestId) {
	const pending = pendingConnections.get(requestId);
	if (!pending) return {
		success: false,
		error: "No pending connection"
	};
	pending.resolve(false);
	return { success: true };
}
async function getAccounts(origin) {
	const walletData = await loadWalletData();
	if (!walletData || !unlockedSeed) return {
		success: true,
		data: { accounts: [] }
	};
	if (!walletData.approvedOrigins.includes(origin)) return {
		success: true,
		data: { accounts: [] }
	};
	return {
		success: true,
		data: { accounts: [walletData.address] }
	};
}
async function setNetwork(network) {
	const walletData = await loadWalletData();
	if (!walletData) return {
		success: false,
		error: "No wallet"
	};
	walletData.network = network;
	await saveWalletData(walletData);
	return { success: true };
}
async function hasWallet() {
	return {
		success: true,
		data: { hasWallet: await loadWalletData() !== null }
	};
}
async function loadAssets() {
	return new Promise((resolve) => {
		chrome.storage.local.get(["trackedAssets"], (result) => {
			resolve(result.trackedAssets ?? []);
		});
	});
}
async function saveAssets(assets) {
	return new Promise((resolve) => {
		chrome.storage.local.set({ trackedAssets: assets }, resolve);
	});
}
async function getAssets() {
	return {
		success: true,
		data: { assets: await loadAssets() }
	};
}
async function addAsset(payload) {
	const chain = payload.chain;
	const chainInfo = CHAINS[chain];
	if (!chainInfo) return {
		success: false,
		error: `Unsupported chain: ${chain}`
	};
	const address = (payload.address ?? "").trim();
	if (!validateAddress(chain, address)) return {
		success: false,
		error: `Invalid ${chainInfo.name} address`
	};
	const contract = payload.contract?.trim();
	let symbol = chain;
	let name = chainInfo.name;
	let decimals;
	if (contract) {
		if (!chainInfo.tokens || chain !== "ETH" && chain !== "BNB" && chain !== "POL") return {
			success: false,
			error: `Tokens are not supported on ${chainInfo.name}`
		};
		if (!/^0x[0-9a-fA-F]{40}$/.test(contract)) return {
			success: false,
			error: "Invalid token contract address"
		};
		try {
			const meta = await fetchTokenMeta(chain, contract);
			symbol = meta.symbol;
			decimals = meta.decimals;
			const std = chain === "ETH" ? "ERC-20" : chain === "BNB" ? "BEP-20" : "Polygon ERC-20";
			name = `${meta.symbol} (${std})`;
		} catch (e) {
			return {
				success: false,
				error: `Token lookup failed: ${e.message}`
			};
		}
	}
	const assets = await loadAssets();
	if (assets.find((a) => a.chain === chain && a.address.toLowerCase() === address.toLowerCase() && (a.contract ?? "").toLowerCase() === (contract ?? "").toLowerCase())) return {
		success: false,
		error: "This asset is already in your list"
	};
	const asset = {
		id: crypto.randomUUID(),
		chain,
		symbol,
		name,
		address,
		contract: contract || void 0,
		decimals
	};
	assets.push(asset);
	await saveAssets(assets);
	return {
		success: true,
		data: { asset }
	};
}
async function removeAsset(id) {
	const assets = await loadAssets();
	const next = assets.filter((a) => a.id !== id);
	if (next.length === assets.length) return {
		success: false,
		error: "Asset not found"
	};
	await saveAssets(next);
	return { success: true };
}
async function refreshAssets() {
	const assets = await loadAssets();
	return {
		success: true,
		data: { balances: await Promise.all(assets.map((a) => fetchAssetBalance(a))) }
	};
}
async function getChainAddresses() {
	if (!unlockedSeed) return {
		success: false,
		error: "Wallet is locked"
	};
	const addresses = {};
	for (const chain of [
		"BTC",
		"ETH",
		"BNB",
		"POL",
		"SOL",
		"XRP",
		"DOGE",
		"LTC"
	]) try {
		addresses[chain] = deriveAddress(unlockedSeed, chain);
	} catch {}
	return {
		success: true,
		data: { addresses }
	};
}
async function sendExternal(payload) {
	if (!unlockedSeed) return {
		success: false,
		error: "Wallet is locked"
	};
	const { chain, to, amount, contract, decimals } = payload;
	if (!isSignableChain(chain)) return {
		success: false,
		error: `Sending on ${chain} is not supported yet (watch-only)`
	};
	if (!to?.trim()) return {
		success: false,
		error: "Recipient address required"
	};
	if (!amount?.trim()) return {
		success: false,
		error: "Amount required"
	};
	try {
		if (chain === "BTC") {
			if (contract) return {
				success: false,
				error: "Tokens are not supported on Bitcoin"
			};
			return {
				success: true,
				data: await sendBtc(unlockedSeed, to.trim(), amount.trim())
			};
		}
		const token = contract ? {
			contract,
			decimals: decimals ?? 18
		} : void 0;
		return {
			success: true,
			data: await sendEvm(unlockedSeed, chain, to.trim(), amount.trim(), token)
		};
	} catch (e) {
		return {
			success: false,
			error: e.message
		};
	}
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
	const { type, payload = {} } = message;
	const handle = async () => {
		switch (type) {
			case "EGO_HAS_WALLET": return hasWallet();
			case "EGO_GENERATE_WALLET": return generateWallet(payload.password);
			case "EGO_IMPORT_WALLET": return importWallet(payload.input, payload.password);
			case "EGO_UNLOCK": return unlockWallet(payload.password);
			case "EGO_LOCK": return lockWallet();
			case "EGO_GET_STATE": return getWalletState();
			case "EGO_GET_ADDRESS": {
				const wd = await loadWalletData();
				if (!wd) return {
					success: false,
					error: "No wallet"
				};
				return {
					success: true,
					data: { address: wd.address }
				};
			}
			case "EGO_GET_BALANCE": return getWalletBalance();
			case "EGO_SEND_TX": return sendTransaction(payload);
			case "EGO_SIGN_MESSAGE": return handleSignMessage(payload.message);
			case "EGO_GET_MNEMONIC": return getMnemonic(payload.password);
			case "EGO_CONNECT_DAPP": return handleConnectDapp(payload);
			case "EGO_APPROVE_CONNECTION": return approveConnection(payload.requestId);
			case "EGO_REJECT_CONNECTION": return rejectConnection(payload.requestId);
			case "EGO_GET_ACCOUNTS": return getAccounts(sender.origin ?? sender.url ?? "");
			case "EGO_SET_NETWORK": return setNetwork(payload.network);
			case "EGO_GET_HEALTH": {
				const rpcUrl = getRpcUrl((await loadWalletData())?.network);
				try {
					return {
						success: true,
						data: await getHealth(rpcUrl)
					};
				} catch (e) {
					return {
						success: false,
						error: e.message
					};
				}
			}
			case "EGO_GET_BLOCKS": {
				const rpcUrl = getRpcUrl((await loadWalletData())?.network);
				try {
					return {
						success: true,
						data: await getBlocks(rpcUrl)
					};
				} catch (e) {
					return {
						success: false,
						error: e.message
					};
				}
			}
			case "EGO_GET_TXS": {
				const rpcUrl = getRpcUrl((await loadWalletData())?.network);
				try {
					return {
						success: true,
						data: await getTransactions(rpcUrl)
					};
				} catch (e) {
					return {
						success: false,
						error: e.message
					};
				}
			}
			case "EGO_FAUCET": {
				const wd = await loadWalletData();
				if (!wd) return {
					success: false,
					error: "No wallet"
				};
				const rpcUrl = getRpcUrl(wd.network);
				try {
					return {
						success: true,
						data: await requestFaucet(wd.address, rpcUrl)
					};
				} catch (e) {
					return {
						success: false,
						error: e.message
					};
				}
			}
			case "EGO_GET_ASSETS": return getAssets();
			case "EGO_ADD_ASSET": return addAsset(payload);
			case "EGO_REMOVE_ASSET": return removeAsset(payload.id);
			case "EGO_REFRESH_ASSETS": return refreshAssets();
			case "EGO_GET_CHAIN_ADDRESSES": return getChainAddresses();
			case "EGO_SEND_EXTERNAL": return sendExternal(payload);
			default: return {
				success: false,
				error: `Unknown message type: ${type}`
			};
		}
	};
	handle().then(sendResponse).catch((err) => {
		sendResponse({
			success: false,
			error: String(err)
		});
	});
	return true;
});
chrome.runtime.onInstalled.addListener(() => {
	console.log("[Ego Wallet] Extension installed.");
});
chrome.runtime.onStartup.addListener(() => {
	unlockedSeed = null;
});
//#endregion
